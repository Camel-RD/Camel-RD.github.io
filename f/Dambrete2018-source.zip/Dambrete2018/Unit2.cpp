// ---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

// ---------------------------------------------------------------------------
#pragma package(smart_init)
#include <System.hpp>
#include <System.Math.hpp>
#include <Classes.hpp>
#include "Unit2.h"

int dx[5] =
{0, 1, -1, -1, 1};
int dy[5] =
{0, -1, -1, 1, 1};
int dd[5] =
{0, 3, 4, 1, 2};
int ddx[4] =
{2, 3, 0, 1};

struct TPiece
{
	int ln;
	int n;
	bool q;
};

TPiece m[13], b[13];
TPiece om[13], ob[13];

int MaxLev = 7;
int GameTickCount; // for last FindIt call
int GameTickCountX; // for FindItX call
int GameGMCount; // times a b pruning was positive
int StartMaxLev;
int GoOutCt; // times maxlev was reduced due to time limit overrun
int WCount, BCount; // count white / black pieces
int WqCount, BqCount; // count white / black quien pieces
int TestedMovesCount; // tested moves in last FindIt call
int TestedMovesCountX;

bool FDLoop;
bool StopThinking; // enforce clean game stop
bool ThinkFaster; // by reducing maxlev
bool HaveMessage;
bool QChecked; // supposed for reducing maxlev when going in quiens
int TimeMin; // used in FindItX
AnsiString SHist; // ... for debug inforamtion

TCell TCell0 =
{' ', 0};
TCell l[8][8]; // game field
TCell ol[8][8];
TCell *li = &l[0][0]; // simple indexed field

// holds some info for each field cell
struct TMoveX
{
	int x;
	int y;
	int n;
	int MovesInDir[4];
	int MovesCount;
	int Moves[4];
	TCell *li;
	TMoveX *MovesX[4];
	TCell *Movesli[4];
	int BeetMovesCount;
	int BeetMoves1[4], BeetMoves2[4];
	TMoveX *BeetMoves1X[4], *BeetMoves2X[4];
	TCell *BeetMoves1li[4], *BeetMoves2li[4];

	int QMovesCount[4];
	int QMovesDir[4], QMovesZDir[4];
	int QMoves[4][8];
	TMoveX *QMovesX[4][8];
	TCell *QMovesli[4][8];
};

TMoveX FieldXYB[8][8];
TMoveX FieldXYM[8][8];
TMoveX *FieldAB = &FieldXYB[0][0];
TMoveX *FieldAM = &FieldXYM[0][0];

typedef TMoveX TFieldXY[8][8];

struct TMoveRec
{
	char State;
	int v, v0; // directions
	int Ln0, Ln1, Lnx; // cell nr
	TCell MoveC; // beeten Piece in Cell
	TPiece MoveP;
};

struct TLevel
{
	int LevNr;
	char WhoGoes, ZWhoGoes; // ZWhoGoes - oponent m/b
	int CurPieceNr;
	int CurPieceLn;
	bool CurIsQ;
	bool CurIsQx;
	bool Beet;
	int MovesCount;
	int MoveV;
	int OldPieceLn;
	int MLN;
	int MVN;
	int MKN;
	TMoveRec MoveRec[20];

	int Rate, RateA, RateB;

	int PieceCount;

	TPiece *Gbm, *ZGbm;
	int DMax;
	int *GqCount, *ZGqCount;

	TMoveX(*MoveToXY)[8][8]; // pointers to move systems

	TMoveX *MoveToA;

};

TLevel GotResult;
TLevel *CurLev;
TLevel Levels[40];

void ClearLev0();

void RateLev0A();
void RateLev1A();
bool RateLev2A();
void(*RateLev0)() = RateLev0A;
void(*RateLev1)() = RateLev1A;
bool(*RateLev2)() = RateLev2A;

void nextlev1(bool &rez);
void nextlev2(bool &rez);
void(*nextlev)(bool &rez) = nextlev1;

int abs(int n)
{
	return (n > 0 ? n : -n);
};

void deffmovexy(TFieldXY &f)
{
	int x, y, x1, y1, k = 0, n = 0, i;
	int mx1, my1;
	TMoveX *m1, *m2;
	for (x = 0; x < 8; x++)
	{
		for (y = 0; y < 8; y++)
		{
			m1 = &f[x][y];
			m1->x = x;
			m1->y = y;
			m1->n = n;
			m1->li = &li[n];
			n++;
		};
	};
	k = 0;
	for (x = 0; x < 8; x++)
	{
		for (y = 0; y < 4; y++)
		{
			y1 = y * 2 + (x + 1) % 2;
			m1 = &f[x][y1];
			for (n = 1; n < 5; n++)
			{
				m1->MovesInDir[n - 1] = -1;
				mx1 = x + dx[n];
				my1 = y1 + dy[n];
				if (VXY(mx1, my1))
				{
					m2 = &f[mx1][my1];
					m1->MovesInDir[n - 1] = m2->n;
				};
			};
		};
	};
};

// dir0 = 0 or 2
void deffmovexyBM(TFieldXY &f, int dir0)
{
	int x, y, y1, k = 0, a1, a2, a3, i, j;
	TMoveX *ff, *m1, *m2, *m3;
	ff = &f[0][0];

	for (x = 0; x < 8; x++)
	{
		for (y = 0; y < 4; y++)
		{
			y1 = y * 2 + (x + 1) % 2;
			m1 = &f[x][y1];

			m1->MovesCount = 0;

			a1 = m1->MovesInDir[dir0];
			if (a1 > -1)
			{
				m2 = &ff[a1];
				m1->Moves[m1->MovesCount] = m2->n;
				m1->MovesX[m1->MovesCount] = m2;
				m1->Movesli[m1->MovesCount] = m2->li;
				m1->MovesCount++;
			};

			a1 = m1->MovesInDir[dir0 + 1];
			if (a1 > -1)
			{
				m2 = &ff[a1];
				m1->Moves[m1->MovesCount] = m2->n;
				m1->MovesX[m1->MovesCount] = m2;
				m1->Movesli[m1->MovesCount] = m2->li;
				m1->MovesCount++;
			};

			m1->BeetMovesCount = 0;
			for (i = 0; i < 4; i++)
			{
				a1 = m1->MovesInDir[i];
				if (a1 == -1)
				{
					continue;
				}
				m2 = &ff[a1];
				a2 = m2->MovesInDir[i];
				if (a2 == -1)
				{
					continue;
				}
				m3 = &ff[a2];
				m1->BeetMoves1[m1->BeetMovesCount] = m2->n;
				m1->BeetMoves2[m1->BeetMovesCount] = m3->n;
				m1->BeetMoves1X[m1->BeetMovesCount] = m2;
				m1->BeetMoves2X[m1->BeetMovesCount] = m3;
				m1->BeetMoves1li[m1->BeetMovesCount] = m2->li;
				m1->BeetMoves2li[m1->BeetMovesCount] = m3->li;
				m1->BeetMovesCount++;
			};

			for (i = 0; i < 4; i++)
			{
				m1->QMovesCount[i] = 0;
				m2 = m1;
				for (j = 0; j < 8; j++)
				{
					a1 = m2->MovesInDir[i];
					if (a1 == -1)
					{
						break;
					}
					m1->QMovesCount[i]++;
					m2 = &ff[a1];
					m1->QMoves[i][j] = m2->n;
					m1->QMovesX[i][j] = m2;
					m1->QMovesli[i][j] = m2->li;
				};
			};

		};
	};
};

void defmovesf()
{
	int i;
	deffmovexy(FieldXYB);
	deffmovexyBM(FieldXYB, 2);
	deffmovexy(FieldXYM);
	deffmovexyBM(FieldXYM, 0);
	for (i = 0; i < 20; i++)
	{
		if (i % 2 == 0)
		{
			Levels[i].MoveToXY = &FieldXYB;
			Levels[i].MoveToA = FieldAB;
		}
		else
		{
			Levels[i].MoveToXY = &FieldXYM;
			Levels[i].MoveToA = FieldAM;
		};
	};

};

const TCell& GetLxy(int x, int y)
{
	return l[x][y];
};

TCell* GetL()
{
	TCell* lx = new TCell[64];
	for(int i = 0; i < 64; i++)
		lx[i] = li[i];
	return lx;
};

void defl0()
{
	int i = 0, j;
	for (j = 0; j < 19; j++)
	{
		Levels[i].ZWhoGoes = 'm';
		Levels[i].MKN = 0;
		Levels[i].Gbm = b;
		Levels[i].ZGbm = m;
		Levels[i].DMax = 7;
		Levels[i].GqCount = &WqCount;
		Levels[i].ZGqCount = &BqCount;
		Levels[i++].WhoGoes = 'b';
		Levels[i].ZWhoGoes = 'b';
		Levels[i].MKN = 0;
		Levels[i].Gbm = m;
		Levels[i].ZGbm = b;
		Levels[i].DMax = 0;
		Levels[i].GqCount = &BqCount;
		Levels[i].ZGqCount = &WqCount;
		Levels[i++].WhoGoes = 'm';
	}
	for (j = 0; j < 40; j++)
	{
		Levels[j].LevNr = j;
	};
}

void ClearBoard()
{
	int i, j;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			l[i][j].N = 0;
			l[i][j].C = ' ';
			l[i][j].Q = false;
		}
	}
	for (i = 1; i < 13; i++)
	{
		b[i].ln = -1;
		b[i].q = false;
		m[i].ln = -1;
		m[i].q = false;
	};
}

void defl1()
{
	int i, j;
	TPiece *f1;
	TCell *bc;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			l[i][j].N = 0;
			l[i][j].C = ' ';
			l[i][j].Q = false;
		}
	}
	for (i = 1; i < 13; i++)
	{
		f1 = &b[i];
		if (f1->ln != -1)
		{
			bc = &li[f1->ln];
			bc->C = 'b';
			bc->N = i;
			bc->Q = f1->q;
		};

		f1 = &m[i];
		if (f1->ln != -1)
		{
			bc = &li[f1->ln];
			bc->C = 'm';
			bc->N = i;
			bc->Q = f1->q;
		};
	}
};

void SwapSides()
{
	int i;
	TPiece *f1, f2;
	TCell *bc;
	for (i = 0; i < 64; i++)
	{
		li[i].N = 0;
		li[i].C = ' ';
		li[i].Q = false;
	}
	for (i = 1; i < 13; i++)
	{
		f2 = b[i];
		b[i] = m[i];
		m[i] = f2;

		f1 = &b[i];
		if (f1->ln != -1)
		{
			f1->ln = FieldXYB[7 - FieldAB[f1->ln].x][7 - FieldAB[f1->ln].y].n;
			bc = &li[f1->ln];
			bc->C = 'b';
			bc->N = i;
			bc->Q = f1->q;
		};

		f1 = &m[i];
		if (f1->ln != -1)
		{
			f1->ln = FieldXYB[7 - FieldAB[f1->ln].x][7 - FieldAB[f1->ln].y].n;
			bc = &li[f1->ln];
			bc->C = 'm';
			bc->N = i;
			bc->Q = f1->q;
		};
	}
};

void StirUp()
{
	int i, n1, n2;
	TPiece f1;
	for (i = 1; i < 30; i++)
	{
		n1 = Random(12) + 1;
		n2 = Random(12) + 1;
		if (n1 == n2)
		{
			continue;
		}
		f1 = b[n1];
		b[n1] = b[n2];
		b[n2] = f1;
		li[b[n1].ln].N = n1;
		li[b[n2].ln].N = n2;
	};
};

void defPieces()
{
	int abx[13] =
	{0, 0, 1, 1, 2, 3, 3, 4, 5, 5, 6, 7, 7};
	int aby[13] =
	{0, 1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 2};
	int amx[13] =
	{0, 0, 0, 1, 2, 2, 3, 4, 4, 5, 6, 6, 7};
	int amy[13] =
	{0, 5, 7, 6, 5, 7, 6, 5, 7, 6, 5, 7, 6};
	int i;
	TPiece *f1;
	for (i = 1; i < 13; i++)
	{
		f1 = &b[i];
		f1->ln = FieldXYB[abx[i]][aby[i]].n;
		f1->q = false;
		f1 = &m[i];
		f1->ln = FieldXYB[amx[i]][amy[i]].n;
		f1->q = false;
	}

	defl1();
};

INL void GetKxy(int kn, char c, int &x, int &y)
{
	int ln;
	if (c == 'b')
	{
		ln = b[kn].ln;
	}
	else
	{
		ln = m[kn].ln;
	};
	x = FieldAB[ln].x;
	y = FieldAB[ln].y;
};

INL void SetKxy(int kn, char c, int x, int y)
{
	int ln;
	ln = FieldXYB[x][y].n;
	if (c == 'b')
	{
		b[kn].ln = ln;
	}
	else
	{
		m[kn].ln = ln;
	};
};

INL TPiece * GetKz(int kn, char c)
{
	return (c == 'b') ? &b[kn] : &m[kn];
};

// INL bool vxy(int x,int y)
// { return ((x>0) && (x<9) && (y>0) && (y<9));
// };

INL void CanGo1(int x, int y, int v, bool &rez)
{
	int d1, d2;
	if (l[x][y].C == 'b')
	{
		d1 = 3;
		d2 = 4;
	}
	else
	{
		d1 = 1;
		d2 = 2;
	};
	rez = false;
	if ((v == d1) || (v == d2))
	{
		x += dx[v];
		y += dy[v];
		if (VXY(x, y))
		{
			if (l[x][y].C == ' ')
			{
				rez = true;
			}
		}
	}
};

INL void CanGo2(int x, int y, int v, char c, int &rez)
{
	int i, d1, d2, x1, y1;
	rez = 0;
	if (c == 'b')
	{
		d1 = 3;
		d2 = 4;
	}
	else
	{
		d1 = 1;
		d2 = 2;
	};
	i = (v == -1) ? d1 : v + 1;

	if ((i == d1) || (i == d2))
	{
		x1 = x + dx[i];
		y1 = y + dy[i];
		if (VXY(x1, y1))
		{
			if (l[x1][y1].C == ' ')
			{
				rez = i;
				return;
			}
		};
	};

	i++;
	if ((i == d1) || (i == d2))
	{
		x1 = x + dx[i];
		y1 = y + dy[i];
		if (VXY(x1, y1))
		{
			if (l[x1][y1].C == ' ')
			{
				rez = i;
				return;
			}
		};
	};
};

// for first move v=-1
INL void CanGo2X(int ln0, int v, int &rez)
{
	TMoveX *m1 = &CurLev->MoveToA[ln0];
	rez = -1;
	v++;
	if (v >= m1->MovesCount)
	{
		return;
	}
	if (m1->Movesli[v]->C == ' ')
	{
		rez = v;
		return;
	};
	v++;
	if (v >= m1->MovesCount)
	{
		return;
	}
	if (m1->Movesli[v]->C == ' ')
	{
		rez = v;
		return;
	};
};

INL void GoDontBeetkX(bool &rez)
{
	int i, ln, d;
	i = CurLev->CurPieceNr;
	d = -1;
	while ((i < 12) && (d == -1))
	{
		i++;
		ln = CurLev->Gbm[i].ln;
		if (ln == -1)
		{
			continue;
		}
		CanGo2X(ln, -1, d);
	};
	if (d > -1)
	{
		CurLev->CurPieceNr = i;
		CurLev->CurPieceLn = ln;
		CurLev->MovesCount = 1;
		CurLev->MoveV = -1;
		rez = false;
	}
	else
		rez = true;
};

INL void GoDontBeetp1X(int ln0, int v)
{
	int ln;
	CurLev->OldPieceLn = ln0;
	ln = CurLev->MoveToA[ln0].Moves[v];
	TCell &b1 = li[ln0];
	TCell &b2 = li[ln];
	b2 = b1;
	b1 = TCell0;
	CurLev->CurPieceLn = ln;
	CurLev->MoveV = v;
	CurLev->Gbm[b2.N].ln = ln;
};

INL void GoDontBeetp2X(bool &rez)
{
	int ln, d1, d2;
	if (CurLev->MovesCount != 1)
	{
		rez = true;
		return;
	};

	ln = CurLev->CurPieceLn;
	d1 = CurLev->MoveV;
	CanGo2X(ln, d1, d2);
	if (d2 == -1)
	{
		rez = true;
	}
	else
	{
		rez = false;
		GoDontBeetp1X(ln, d2);
		CurLev->MovesCount = 2;
	};

};

INL void GoDontBeetm1X(bool &rez)
{
	int ln, ln1;
	if (CurLev->MovesCount != 2)
	{
		rez = true;
		return;
	};

	rez = false;
	CurLev->MovesCount = 1;
	ln = CurLev->CurPieceLn;

	TCell &b1 = li[ln];

	ln1 = CurLev->OldPieceLn;
	TCell &b2 = li[ln1];

	b2 = b1;
	b1 = TCell0;
	CurLev->Gbm[b2.N].ln = ln1;

	CurLev->CurPieceLn = ln1;

};

void GoDontBeet(bool &rez)
{
	bool o, p, p1, o1;
	o = false;

	if (CurLev->MovesCount == 0)
	{
		GoDontBeetkX(o);
	}
	if (o)
	{
		rez = true;
	}
	else
	{
		do
		{
			GoDontBeetp2X(o);
			p = false;
			p1 = false;
			if (o)
			{
				GoDontBeetm1X(p);
				if (p)
				{
					GoDontBeetkX(p1);
				}
			};
			o1 = ((!o) || ((p) && (p1)));
		}
		while (!o1);
		rez = o;
	};

};

INL void CanBeet1(int x, int y, int v, bool &rez)
{
	char c;
	rez = false;
	if (l[x][y].C == 'b')
	{
		c = 'm';
	}
	else
		c = 'b';
	x += dx[v];
	y += dy[v];
	if (VXY(x, y))
	{
		if (l[x][y].C == c)
		{
			x += dx[v];
			y += dy[v];
			if (VXY(x, y))
			{
				rez = (l[x][y].C == ' ');
			}
		}
	}
};

INL void CanBeet2X(int ln, int v, int &rez)
{
	char c = CurLev->ZWhoGoes;
	TMoveX *m1 = &FieldAB[ln];
	rez = -1;
	while (v < 3)
	{
		v++;
		if (v >= m1->BeetMovesCount)
		{
			return;
		}
		if ((m1->BeetMoves1li[v]->C == c) && (m1->BeetMoves2li[v]->C == ' '))
		{
			rez = v;
			return;
		};
	}
};

INL void CanBeet2Xc(char c, int ln, int v, int &rez)
{
	char zc;
	TMoveX *m1;
	if (c == 'b')
	{
		zc = 'm';
		m1 = &FieldAB[ln];
	}
	else
	{
		zc = 'b';
		m1 = &FieldAM[ln];
	};
	rez = -1;
	while (v < 3)
	{
		v++;
		if (v >= m1->BeetMovesCount)
		{
			return;
		}
		if ((m1->BeetMoves1li[v]->C == zc) && (m1->BeetMoves2li[v]->C == ' '))
		{
			rez = v;
			return;
		};
	}
};

INL void CanBeetX(bool &rez)
{
	int i, ln, d;
	char c = CurLev->WhoGoes;
	char c1 = CurLev->ZWhoGoes;
	d = -1;
	rez = true;
	for (i = 1; i < 13; i++)
	{
		ln = CurLev->Gbm[i].ln;
		if (ln == -1)
		{
			continue;
		}
		CanBeet2X(ln, -1, d);
		if (d > -1)
		{
			return;
		}
	};
	rez = false;
};

INL void Beetp1X(int ln, int v)
{
	int ln1, ln2, mc;
	TCell &b1 = li[ln];
	ln1 = FieldAB[ln].BeetMoves1[v];
	TCell &b2 = li[ln1];
	ln2 = FieldAB[ln].BeetMoves2[v];
	TCell &b3 = li[ln2];

	mc = CurLev->MovesCount;
	TMoveRec &mr = CurLev->MoveRec[mc];
	mr.v = v;
	mr.MoveC = b2;
	mr.MoveP = CurLev->ZGbm[b2.N];
	mr.Ln0 = ln;
	mr.Ln1 = ln1;

	CurLev->CurPieceLn = ln2;

	TPiece *f1;
	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln2;
		f1 = &m[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			BqCount--;
		}
		BCount--;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln2;
		f1 = &b[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			WqCount--;
		}
		WCount--;
	}

	b3 = b1;
	b1 = TCell0;
	b2 = TCell0;
};

INL void Beetm1X(bool &rez)
{
	int ln, ln1, ln2;
	rez = (CurLev->MovesCount == 1);
	if (rez)
	{
		return;
	}

	CurLev->MovesCount--;
	TMoveRec &mr = CurLev->MoveRec[CurLev->MovesCount];

	ln = CurLev->CurPieceLn;
	TCell &b1 = li[ln];

	ln1 = mr.Ln1;
	TCell &b2 = li[ln1];

	ln2 = mr.Ln0;
	TCell &b3 = li[ln2];

	CurLev->CurPieceLn = ln2;

	b2 = mr.MoveC;

	TPiece *f1;

	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln2;
		f1 = &m[b2.N];
		if (f1->q)
		{
			BqCount++;
		}
		f1->ln = ln1;
		BCount++;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln2;
		f1 = &b[b2.N];
		if (f1->q)
		{
			WqCount++;
		}
		f1->ln = ln1;
		WCount++;
	};

	b3 = b1;
	b1 = TCell0;

};

INL void Beetp2X(bool &rez)
{
	int ln, d1, d2;
	ln = CurLev->CurPieceLn;
	d1 = CurLev->MoveRec[CurLev->MovesCount].v;
	CanBeet2X(ln, d1, d2);
	if (d2 == -1)
	{
		rez = true;
	}
	else
	{
		rez = false;
		do
		{
			Beetp1X(ln, d2);
			CurLev->MovesCount++;
			ln = CurLev->CurPieceLn;
			d1 = -1;
			CurLev->MoveRec[CurLev->MovesCount].v = -1;
			CanBeet2X(ln, d1, d2);
		}
		while (d2 > -1);
	}
};

INL void BeetkX(bool &rez)
{
	int i, ln, d;
	if (CurLev->MKN > 0)
	{
		i = CurLev->MKN - 1;
		CurLev->MKN = 0;
	}
	else
		i = CurLev->CurPieceNr;

	d = -1;
	while ((i < 12) && (d == -1))
	{
		i++;
		ln = CurLev->Gbm[i].ln;
		if (ln == -1)
		{
			continue;
		}
		CanBeet2X(ln, -1, d);
	};
	if (d > -1)
	{
		CurLev->CurPieceNr = i;
		CurLev->CurPieceLn = ln;
		CurLev->MovesCount = 1;
		CurLev->MoveRec[1].v = -1;
		rez = false;
	}
	else
		rez = true;
};

void BeetX(bool &rez)
{
	bool o, p, p1, o1;
	o = false;
	if (CurLev->MovesCount == 0)
	{
		BeetkX(o);
	}
	if (o)
	{
		rez = true;
	}
	else
	{
		do
		{
			Beetp2X(o);
			p = false;
			p1 = false;
			if (o)
			{
				Beetm1X(p);
				if (p)
				{
					BeetkX(p1);
				}
			};
			o1 = ((!o) || ((p) && (p1)));
		}
		while (!o1);
		rez = o;
	};
};

INL void dCanGo1X(int ln0, int &v, int &vn, int &ln)
{
	int vn1 = vn;
	int v1 = v;
	TMoveX *m1 = &FieldAB[ln0];
	v = -1;
	vn = -1;
	vn1++;
	if (v1 > -1)
	{
		if (vn1 < m1->QMovesCount[v1])
		{
			ln = m1->QMoves[v1][vn1];
			if (li[ln].C == ' ')
			{
				v = v1;
				vn = vn1;
				return;
			};
		};
	};
	vn1 = 0;
	while (v1 < 3)
	{
		v1++;
		if (m1->QMovesCount[v1] > 0)
		{
			ln = m1->QMoves[v1][0];
			if (li[ln].C == ' ')
			{
				v = v1;
				vn = 0;
				return;
			};
		};
	};

};

INL void dGoDontBeetkX(bool &rez)
{
	int i, ln, v = -1, vn, ln1;
	TPiece *f1;
	i = CurLev->CurPieceNr;
	rez = true;

	while ((i < 12) && (rez))
	{
		i++;
		f1 = &CurLev->Gbm[i];
		ln = f1->ln;
		if (ln == -1)
		{
			continue;
		}

		CurLev->CurIsQ = f1->q;
		CurLev->CurIsQx = f1->q;
		if (f1->q)
		{
			ln1 = ln;
			vn = -1;
			dCanGo1X(ln, v, vn, ln1);
			if (vn > -1)
			{
				CurLev->CurPieceNr = i;
				CurLev->CurPieceLn = ln;
				CurLev->OldPieceLn = ln;
				CurLev->MovesCount = 1;
				CurLev->MoveV = -1;
				CurLev->MLN = ln;
				CurLev->MVN = vn;
				rez = false;
			};
		}
		else
		{
			CanGo2X(ln, -1, v);
			if (v > -1)
			{
				CurLev->CurPieceNr = i;
				CurLev->CurPieceLn = ln;
				CurLev->MovesCount = 1;
				CurLev->MoveV = -1;
				rez = false;
			};
		};
	};
};

INL void dGoDontBeetp1X(int ln, int ln1, int v, int vn)
{
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];
	b2 = b1;
	b1 = TCell0;
	CurLev->CurPieceLn = ln1;
	CurLev->MoveV = v;
	CurLev->MLN = ln1;
	CurLev->MVN = vn;
	CurLev->OldPieceLn = ln;
	CurLev->Gbm[b2.N].ln = ln1;
};

INL void dGoDontBeetp1(int x, int y, int v, int zx, int zy)
{
	TCell &b1 = l[x][y];
	TCell &b2 = l[zx][zy];
	b2 = b1;
	b1 = TCell0;
	CurLev->CurPieceLn = FieldXYB[zx][zy].n;
	CurLev->MoveV = v;
	CurLev->MLN = FieldXYB[zx][zy].n;
	CurLev->OldPieceLn = FieldXYB[x][y].n;
	CurLev->Gbm[b2.N].ln = FieldXYB[zx][zy].n;
};

INL void dGoDontBeetp2X(bool &rez)
{
	int ln, v, vn, ln1;
	rez = (CurLev->MovesCount != 1);
	if (rez)
	{
		return;
	}

	ln = CurLev->CurPieceLn;
	v = CurLev->MoveV;
	vn = CurLev->MVN;

	dCanGo1X(ln, v, vn, ln1);
	if (vn == -1)
	{
		rez = true;
	}
	else
	{
		dGoDontBeetp1X(ln, ln1, v, vn);
		CurLev->MovesCount++;
	};
};

INL void dGoDontBeetm1X(bool &rez)
{
	int ln, ln1;
	rez = (CurLev->MovesCount == 1);
	if (rez)
	{
		return;
	}

	CurLev->MovesCount--;
	ln = CurLev->CurPieceLn;
	ln1 = CurLev->OldPieceLn;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];
	b2 = b1;
	b1 = TCell0;
	CurLev->Gbm[b2.N].ln = ln1;
	CurLev->CurPieceLn = ln1;
};

INL void dGoDontBeetX(bool &rez)
{
	bool o, p, p1, o1;
	o = false;
	if (CurLev->MovesCount == 0)
	{
		dGoDontBeetkX(o);
	}
	if (o)
	{
		rez = true;
	}
	else
	{
		do
		{
			if (CurLev->CurIsQ && CurLev->CurIsQx)
			{
				dGoDontBeetp2X(o);
			}
			else
				GoDontBeetp2X(o);
			if (!o)
			{
				if ((FieldAB[CurLev->CurPieceLn].y == CurLev->DMax)
					&& !CurLev->CurIsQ)
				{
					CurLev->Gbm[CurLev->CurPieceNr].q = true;
					li[CurLev->CurPieceLn].Q = true;
					CurLev->CurIsQ = true;
					CurLev->CurIsQx = false;
					(*CurLev->GqCount)++;
					if (QChecked)
					{
						QChecked = false;
						// if(MaxLev>6)   MaxLev -= 2;
					};
				}
			};
			p = false;
			p1 = false;
			if (o)
			{
				if (CurLev->CurIsQ && !CurLev->CurIsQx)
				{
					CurLev->Gbm[CurLev->CurPieceNr].q = false;
					li[CurLev->CurPieceLn].Q = false;
					CurLev->CurIsQ = false;
					(*CurLev->GqCount)--;
				};
				if (CurLev->CurIsQ)
				{
					dGoDontBeetm1X(p);
				}
				else
					GoDontBeetm1X(p);
				if (p)
				{
					dGoDontBeetkX(p1);
				}
			};
			o1 = ((!o) || ((p) && (p1)));
		}
		while (!o1);
		rez = o;
	}
};

/*
 INL void dCanBeet0(int x,int y,int v,int &zx,int &zy)
 { zx=x+dx[v];
 zy=y+dy[v];
 if(VXY(zx,zy))
 if(l[zx][zy].C==' ') return;
 zx=zy=0;
 };
 */

INL void dCanBeet0X(int ln, int v, int &ln1)
{
	if (v == -1)
	{
		ln1 = -1;
		return;
	};
	ln1 = FieldAB[ln].MovesInDir[v];
	if (ln1 == -1)
	{
		return;
	}
	if (li[ln1].C == ' ')
	{
		return;
	}
	ln1 = -1;
};

INL void dCanBeet1(int x, int y, int v, char c, int &zx, int &zy)
{
	int x1, y1;
	zx = 0;
	zy = 0;
	while (1)
	{
		x += dx[v];
		y += dy[v];
		if (!VXY(x, y))
		{
			return;
		}
		if (l[x][y].C == ' ')
		{
			continue;
		}
		if (l[x][y].C == c)
		{
			x1 = x + dx[v];
			y1 = y + dy[v];
			if (!VXY(x1, y1))
			{
				return;
			}
			if (l[x1][y1].C != ' ')
			{
				return;
			}
			zx = x;
			zy = y;
			return;
		};
		return;
	};
};

INL void dCanBeet1X(int ln, int v, int &ln1)
{
	int vn1, mc;
	char c;
	char zc = CurLev->ZWhoGoes;
	if (v == -1)
	{
		v = 0;
	}
	TMoveX &m1 = FieldAB[ln];
	TCell **cx = m1.QMovesli[v];
	mc = m1.QMovesCount[v];
	vn1 = -1;
	ln1 = -1;

	while (1)
	{
		vn1++;
		if (vn1 >= mc)
		{
			return;
		}
		c = cx[vn1]->C;
		if (c == ' ')
		{
			continue;
		}
		if (c == zc)
		{
			vn1++;
			if (vn1 >= mc)
			{
				return;
			}
			if (cx[vn1]->C != ' ')
			{
				return;
			}
			vn1--;
			ln1 = m1.QMoves[v][vn1];
			return;
		};
		return;
	};
};

INL void dCanBeet1Xc(char c, int ln, int v, int &ln1)
{
	int vn1, mc;
	char zc, c1;
	zc = c == 'b' ? 'm' : 'b';
	if (v == -1)
	{
		v = 0;
	}
	TMoveX &m1 = FieldAB[ln];
	TCell **cx = m1.QMovesli[v];
	mc = m1.QMovesCount[v];
	vn1 = -1;
	ln1 = -1;

	while (1)
	{
		vn1++;
		if (vn1 >= mc)
		{
			return;
		}
		c1 = cx[vn1]->C;
		if (c1 == ' ')
		{
			continue;
		}
		if (c1 == zc)
		{
			vn1++;
			if (vn1 >= mc)
			{
				return;
			}
			if (cx[vn1]->C != ' ')
			{
				return;
			}
			vn1--;
			ln1 = m1.QMoves[v][vn1];
			return;
		};
		return;
	};
};

INL void dCanBeet2(int x, int y, char c, int &v, int &zx, int &zy)
{
	int i = v + 1;
	v = 0;
	zx = 0;
	zy = 0;
	while (i < 5)
	{
		dCanBeet1(x, y, i, c, zx, zy);
		if (zx != 0)
		{
			v = i;
			return;
		};
		i++;
	};
};

INL void dCanBeet2X(int ln, int &v, int &ln1)
{
	while (v < 3)
	{
		v++;
		dCanBeet1X(ln, v, ln1);
		if (ln1 != -1)
		{
			return;
		};
	};
	v = -1;
};

INL void dCanBeet2Xc(char c, int ln, int &v, int &ln1)
{
	while (v < 3)
	{
		v++;
		dCanBeet1Xc(c, ln, v, ln1);
		if (ln1 != -1)
		{
			return;
		};
	};
	v = -1;
};

INL void dCanBeet2a(int x, int y, char c, int v0, int &v, int &zx, int &zy)
{
	int i = v;
	v = 0;
	zx = 0;
	zy = 0;
	while (i < 4)
	{
		i++;
		if (i == ddx[v0])
		{
			continue;
		}
		dCanBeet1(x, y, i, c, zx, zy);
		if (zx != 0)
		{
			v = i;
			return;
		};
	};
};

INL void dCanBeet2aX(int ln, int v0, int &v, int &ln1)
{
	while (v < 3)
	{
		v++;
		if (v == ddx[v0])
		{
			continue;
		}
		dCanBeet1X(ln, v, ln1);
		if (ln1 != -1)
		{
			return;
		};
	};
	v = -1;
};

INL void dCanBeet2bX(int ln, int v0, int &v, int &ln1)
{
	while (v < 3)
	{
		v++;
		if (v == v0)
		{
			continue;
		}
		if (v == ddx[v0])
		{
			continue;
		}
		dCanBeet1X(ln, v, ln1);
		if (ln1 != -1)
		{
			return;
		};
	};
	v = -1;
};

INL void dCanBeet3(int x, int y, char c, int v0, int &zx, int &zy)
{
	int v1, x1, y1;
	zx = 0;
	zy = 0;
	while (1)
	{
		v1 = 0;
		x += dx[v0];
		y += dy[v0];
		if (!VXY(x, y))
		{
			return;
		}
		if (l[x][y].C != ' ')
		{
			return;
		}
		dCanBeet2a(x, y, c, v0, v1, x1, y1);
		if (x1 != 0)
		{
			zx = x;
			zy = y;
			return;
		};
	};
};

INL void dCanBeet3X(int ln, int v0, int &v, int &lnx, int &ln1)
{
	int vn2, mc, vn1, ln3;
	if (lnx == -1)
	{
		lnx = ln;
	}

	if (v > -1)
	{

		if (ln == lnx)
		{
			dCanBeet2aX(lnx, v0, v, ln1);
		}
		else
			dCanBeet2bX(lnx, v0, v, ln1);

		if (v != -1)
		{
			return;
		};
	};

	TMoveX &m1 = FieldAB[lnx];
	TCell **cx = m1.QMovesli[v0];
	int *mln = m1.QMoves[v0];
	bool p = ln == lnx;

	mc = m1.QMovesCount[v0];
	vn1 = 0;
	while (1)
	{
		if (vn1 >= mc)
		{
			v = -1;
			lnx = -1;
			return;
		};
		if (cx[vn1]->C != ' ')
		{
			return;
		}
		lnx = mln[vn1];
		v = -1;

		if (p && (vn1 == 0))
		{
			dCanBeet2aX(lnx, v0, v, ln1);
		}
		else
			dCanBeet2bX(lnx, v0, v, ln1);

		if (v != -1)
		{
			return;
		};
		vn1++;
	};
};

// ln1 but not vn !
INL void dBeetp1X(int ln, int ln1)
{
	int &mc = CurLev->MovesCount;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];
	b2 = b1;
	b1 = TCell0;
	CurLev->Gbm[b2.N].ln = ln1;

	CurLev->CurPieceLn = ln1;
	CurLev->MoveRec[mc].Ln1 = ln1;

	// mc++;
	// CurLev->MoveRec[mc].Ln0 = ln1;
	// CurLev->MoveRec[mc].Ln1 = ln1;
};

INL void dBeetp2X(int ln, int ln1, int v)
{
	int &mc = CurLev->MovesCount;
	TMoveRec *mr;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];

	CurLev->CurPieceLn = ln1;
	mr = &(CurLev->MoveRec[mc]);
	mr->v = v;
	mr->MoveC = b2;
	mr->MoveP = CurLev->ZGbm[b2.N];
	mr->Ln1 = ln1;

	mc++;
	mr = &(CurLev->MoveRec[mc]);
	mr->Ln0 = ln1;
	mr->Ln1 = ln1;
	mr->Lnx = -1;
	mr->v = -1;
	mr->v0 = v;

	TPiece *f1;
	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln1;
		f1 = &m[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			BqCount--;
		}
		BCount--;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln1;
		f1 = &b[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			WqCount--;
		}
		WCount--;
	}

	b2 = b1;
	b1 = TCell0;
};

INL void dBeetp3X(int ln, int ln1, int lnx, int v0, int v)
{
	int &mc = CurLev->MovesCount;
	TMoveRec *mr;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];

	CurLev->CurPieceLn = ln1;

	mr = &(CurLev->MoveRec[CurLev->MovesCount]);
	mr->v = v;
	mr->v0 = v0;
	mr->MoveC = b2;
	mr->MoveP = CurLev->ZGbm[b2.N];
	mr->Ln0 = ln;
	mr->Ln1 = ln1;
	mr->Lnx = lnx;

	CurLev->MovesCount++;
	mr = &(CurLev->MoveRec[CurLev->MovesCount]);
	mr->Ln0 = ln1;
	mr->Ln1 = ln1;
	mr->Lnx = -1;
	mr->v = -1;
	mr->v0 = v;

	TPiece *f1;
	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln1;
		f1 = &m[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			BqCount--;
		}
		BCount--;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln1;
		f1 = &b[b2.N];
		f1->ln = -1;
		if (f1->q)
		{
			WqCount--;
		}
		WCount--;
	}

	b2 = b1;
	b1 = TCell0;

};

INL void dBeetm1X(bool &rez)
{
	int ln, ln0;
	rez = false;
	ln = CurLev->CurPieceLn;
	ln0 = CurLev->MoveRec[CurLev->MovesCount].Ln0;
	if (ln == ln0)
	{
		rez = true;
		return;
	};
	CurLev->CurPieceLn = ln0;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln0];
	b2 = b1;
	b1 = TCell0;
	CurLev->Gbm[b2.N].ln = ln0;
};

INL void dBeetm2X(bool &rez)
{
	int ln, ln1;
	TMoveRec *mr = &CurLev->MoveRec[CurLev->MovesCount];
	rez = false;
	ln = CurLev->CurPieceLn;
	TPiece *f1;
	f1 = &mr->MoveP;
	ln1 = mr->Ln0;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];
	TCell &b3 = mr->MoveC;
	CurLev->CurPieceLn = ln1;

	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln1;
		f1 = &m[b3.N];
		f1->ln = ln;
		if (f1->q)
		{
			BqCount++;
		}
		BCount++;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln1;
		f1 = &b[b3.N];
		f1->ln = ln;
		if (f1->q)
		{
			WqCount++;
		}
		WCount++;
	}
	b2 = b1;
	b1 = b3;
};

INL void dBeetm3X(bool &rez)
{
	int ln, ln1;
	TMoveRec *mr = &CurLev->MoveRec[CurLev->MovesCount];
	rez = false;
	ln = CurLev->CurPieceLn;
	TPiece *f1;
	f1 = &mr->MoveP;
	ln1 = mr->Ln0;
	TCell &b1 = li[ln];
	TCell &b2 = li[ln1];
	TCell &b3 = mr->MoveC;
	CurLev->CurPieceLn = ln1;

	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = ln1;
		f1 = &m[b3.N];
		f1->ln = ln;
		if (f1->q)
		{
			BqCount++;
		}
		BCount++;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = ln1;
		f1 = &b[b3.N];
		f1->ln = ln;
		if (f1->q)
		{
			WqCount++;
		}
		WCount++;
	}
	b2 = b1;
	b1 = b3;
};

INL void dBeetkX(bool &rez)
{
	int i, ln, d, ln1;
	char c1 = CurLev->ZWhoGoes;
	TPiece *f1;
	if (CurLev->MKN > 0)
	{
		i = CurLev->MKN - 1;
		CurLev->MKN = 0;
	}
	else
		i = CurLev->CurPieceNr;

	d = -1;
	while ((i < 12) && (d == -1))
	{
		i++;
		f1 = &CurLev->Gbm[i];
		ln = f1->ln;
		if (ln == -1)
		{
			continue;
		}

		if (f1->q)
		{
			dCanBeet2X(ln, d, ln1);
		}
		else
			CanBeet2X(ln, -1, d);
	};

	rez = (d == -1);
	if (rez)
	{
		return;
	}
	CurLev->CurIsQ = f1->q;
	CurLev->CurIsQx = f1->q;

	TMoveRec *mr = &CurLev->MoveRec[1];
	if (f1->q)
	{
		CurLev->CurPieceNr = i;
		CurLev->CurPieceLn = ln;
		CurLev->MovesCount = 1;
		mr->v = -1;
		mr->v0 = -1;
		mr->Ln1 = ln;
		mr->Ln0 = ln;
		mr->State = 0;
	}
	else
	{
		CurLev->CurPieceNr = i;
		CurLev->CurPieceLn = ln;
		CurLev->MovesCount = 1;
		mr->v = -1;
	};

};

INL void dBeetpmX(bool &rez)
{
	int &mc = CurLev->MovesCount;
	rez = false;
	if (mc < 2)
	{
		rez = true;
		return;
	};

	if (CurLev->MoveRec[mc].State != 31)
	{
		mc--;
	}

	switch (CurLev->MoveRec[mc].State)
	{
	case 0:
		dBeetm2X(rez);
		break;

	case 3:
		dBeetm1X(rez);
		break;

	case 31:
		dBeetm1X(rez);
		CurLev->MoveRec[mc].State = 3;
		break;

	case 4:
		dBeetm3X(rez);
		break;
	};

};

INL void dBeetpxX(bool &rez)
{
	int ln, ln0, ln1, ln2, ln3, lnx, v0, v1, vn;
	int &mc = CurLev->MovesCount;
	bool o;

	if (CurLev->MoveRec[mc].State == 5)
	{
		rez = true;
		return;
	};

	TMoveX *m1;
	TMoveRec *mr;
	bool p;
	rez = false;
	p = false;

	do
	{

		mr = &CurLev->MoveRec[mc];

		ln = CurLev->CurPieceLn;
		ln0 = mr->Ln0;
		ln1 = mr->Ln1;
		lnx = mr->Lnx;
		v0 = mr->v0;
		v1 = mr->v;
		m1 = &FieldAB[ln];

		switch (mr->State)
		{
		case 0:
			dCanBeet2X(ln, v1, ln1);
			if (v1 != -1)
			{
				dBeetp2X(ln, ln1, v1);
				CurLev->MoveRec[mc].State = 1;
				break;
			};
			rez = true;
			break;

		case 1:
			dCanBeet3X(ln0, v0, v1, lnx, ln1);
			if (v1 != -1)
			{
				mr->State = 4;
				dBeetp3X(ln, ln1, lnx, v0, v1);
				CurLev->MoveRec[mc].State = 1;
				break;
			};
			mr->State = 3;
			break;

		case 3:
			dCanBeet0X(ln1, v0, ln2);
			if (ln2 != -1)
			{
				dBeetp1X(ln, ln2);
				mr->State = 31;
				p = true;
				break;
			};
			dBeetm1X(o);
			dBeetpmX(o);
			break;

		case 31:
			dCanBeet0X(ln1, v0, ln2);
			if (ln2 != -1)
			{
				dBeetp1X(ln, ln2);
				p = true;
				break;
			};
			dBeetm1X(o);
			mr->State = 3;
			dBeetpmX(o);
			break;

		case 4:
			dCanBeet3X(ln0, v0, v1, lnx, ln1);
			if (v1 != -1)
			{
				dBeetp3X(ln, ln1, lnx, v0, v1);
				CurLev->MoveRec[mc].State = 1;
				break;
			};
			dBeetpmX(o);
			break;

		case 9:
			{
			};
		}
	}
	while (!(rez || p));

};

INL void dBeetX(bool &rez)
{
	bool o, p, p1, o1;
	char c = CurLev->ZWhoGoes;
	o = false;
	if (CurLev->MovesCount == 0)
	{
		dBeetkX(o);
	}
	if (o)
	{
		rez = true;
	}
	else
	{
		do
		{
			if (CurLev->CurIsQ && CurLev->CurIsQx)
			{
				dBeetpxX(o);
			}
			else
				Beetp2X(o);
			if (!o)
			{
				if ((FieldAB[CurLev->CurPieceLn].y == CurLev->DMax)
					&& !CurLev->CurIsQ)
				{
					CurLev->Gbm[CurLev->CurPieceNr].q = true;
					li[CurLev->CurPieceLn].Q = true;
					CurLev->CurIsQ = true;
					CurLev->CurIsQx = false;
					(*CurLev->GqCount)++;
					if (QChecked)
					{
						QChecked = false;
						// if(MaxLev > 6) MaxLev -= 2;
					};
				}
			};
			p = false;
			p1 = false;
			if (o)
			{
				if (CurLev->CurIsQ && !CurLev->CurIsQx)
				{
					CurLev->Gbm[CurLev->CurPieceNr].q = false;
					li[CurLev->CurPieceLn].Q = false;
					CurLev->CurIsQ = false;
					(*CurLev->GqCount)--;
				};
				if (CurLev->CurIsQ)
				{
					dBeetpmX(p);
				}
				else
					Beetm1X(p);
				if (p)
				{
					dBeetkX(p1);
				}
			};
			o1 = ((!o) || ((p) && (p1)));
		}
		while (!o1);
		rez = o;
	};
};

INL void dCanBeet(int &rez)
{
	int i, ln, d, ln1;
	char c1 = CurLev->ZWhoGoes;
	TPiece *f1;
	i = 0;
	d = -1;
	rez = 0;
	while (i < 12)
	{
		i++;
		f1 = &CurLev->Gbm[i];
		ln = f1->ln;
		if (ln == -1)
		{
			continue;
		}

		if (f1->q)
		{
			dCanBeet2X(ln, d, ln1);
		}
		else
			CanBeet2X(ln, -1, d);

		if (d > -1)
		{
			rez = i;
			return;
		};
	};

};

INL void dCanBeetX(char c, int &rez)
{
	int i, ln, d, ln1;
	char c1 = (c == 'b' ? 'm' : 'b');
	TPiece *f1;
	i = 0;
	d = -1;
	rez = 0;
	while (i < 12)
	{
		i++;
		f1 = GetKz(i, c);
		ln = f1->ln;
		if (ln == -1)
		{
			continue;
		}

		if (f1->q)
		{
			dCanBeet2Xc(c, ln, d, ln1);
		}
		else
			CanBeet2Xc(c, ln, -1, d);

		if (d > -1)
		{
			rez = i;
			return;
		};

	};

};

INL void CanGoXX(char c, bool &rez)
{
	int i, ln, d, ln1, vn;
	TPiece *f1;
	i = 0;
	d = -1;
	vn = -1;
	rez = false;
	while ((i < 12))
	{
		i++;
		f1 = GetKz(i, c);
		ln = f1->ln;
		if (ln == -1)
		{
			continue;
		}

		if (f1->q)
		{
			ln1 = ln;
			dCanGo1X(ln, d, vn, ln1);
			rez = (d > -1);
			if (rez)
			{
				return;
			}
		}
		else
		{
			CanGo2(FieldAB[ln].x, FieldAB[ln].y, -1, c, d);
			rez = (d > 0);
			if (rez)
			{
				return;
			}
		};
	};
};

void GoM(bool &rez)
{
	bool o = true;
	if (CurLev->Beet)
	{
		do
		{
			if (CurLev->CurIsQ && !CurLev->CurIsQx)
			{
				CurLev->Gbm[CurLev->CurPieceNr].q = false;
				li[CurLev->CurPieceLn].Q = false;
				CurLev->CurIsQ = false;
				(*CurLev->GqCount)--;
			};
			if (CurLev->CurIsQ)
			{
				dBeetpmX(o);
			}
			else
				Beetm1X(o);
		}
		while (!o);
	}
	else
	{
		do
		{
			if (CurLev->CurIsQ && !CurLev->CurIsQx)
			{
				CurLev->Gbm[CurLev->CurPieceNr].q = false;
				li[CurLev->CurPieceLn].Q = false;
				CurLev->CurIsQ = false;
				(*CurLev->GqCount)--;
			};
			if (CurLev->CurIsQ)
			{
				dGoDontBeetm1X(o);
			}
			else
				GoDontBeetm1X(o);
		}
		while (!o);
	};
	rez = o;
};

void Go(bool &rez)
{
	bool o;
	if (CurLev->Beet)
	{
		dBeetX(o);
	}
	else
		dGoDontBeetX(o);
	rez = o;
};

int CountBs()
{
	int i, j;
	j = 0;
	for (i = 1; i < 13; i++)
	{
		if (m[i].ln == -1)
		{
			continue;
		}
		j++;
	};
	return j;
};

int CountWs()
{
	int i, j;
	j = 0;
	for (i = 1; i < 13; i++)
	{
		if (b[i].ln == -1)
		{
			continue;
		}
		j++;
	};
	return j;
};

int CountBqs()
{
	int i, j;
	j = 0;
	for (i = 1; i < 13; i++)
	{
		if (m[i].ln == -1)
		{
			continue;
		}
		if (m[i].q)
		{
			j++;
		}
	};
	return j;
};

int CountWqs()
{
	int i, j;
	j = 0;
	for (i = 1; i < 13; i++)
	{
		if (b[i].ln == -1)
		{
			continue;
		}
		if (b[i].q)
		{
			j++;
		}
	};
	return j;
};

void ReadRes()
{
	GotResult = Levels[0];
};

void ClearRes()
{
	GotResult.Rate = -1000;
	GotResult.RateA = -1000;
	GotResult.RateB = 1000;
	GotResult.CurPieceNr = 0;
	GotResult.CurPieceLn = -1;
	GotResult.MovesCount = 0;
	GotResult.OldPieceLn = -1;
	GotResult.MoveV = -1;
	GotResult.PieceCount = -1;
};

void RateLev0A()
{
	int d;
	int piececount = BCount + WCount;
	if (BCount == 0)
	{
		d = 300 - CurLev->LevNr;
	}
	else if (WCount == 0)
	{
		d = -300 + CurLev->LevNr;
	}
	else
		d = WCount - BCount - 2 * BqCount + WqCount;

	if (CurLev->WhoGoes == 'b')
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
		}
		else if (d > CurLev->Rate)
		{
			CurLev->Rate = d;
		}
		if (CurLev->LevNr == 0)
		{
			if (CurLev->Rate > GotResult.Rate)
			{
				ReadRes();
			}
		}
	}
	else
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
		}
		else if (d < CurLev->Rate)
		{
			CurLev->Rate = d;
		}
	}
};

void RateLev0Ax()
{
	int d;
	int piececount = BCount + WCount;
	if (BCount == 0)
	{
		d = 300 - CurLev->LevNr;
	}
	else if (WCount == 0)
	{
		d = -300 + CurLev->LevNr;
	}
	else
		d = WCount - BCount - 2 * BqCount + WqCount;

	if (CurLev->WhoGoes == 'b')
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
			CurLev->PieceCount = piececount;
		}
		else if (d > CurLev->Rate)
		{
			CurLev->Rate = d;
			CurLev->PieceCount = piececount;
		}
		else if (d == CurLev->Rate &&
			(CurLev->PieceCount == -1 ||
			 CurLev->PieceCount > piececount))
		{
			CurLev->PieceCount = piececount;
		}
		if (CurLev->LevNr == 0)
		{
			if (CurLev->Rate > GotResult.Rate)
			{
				ReadRes();
			}
			else if (CurLev->Rate == GotResult.Rate &&
				(GotResult.PieceCount == -1 ||
				GotResult.PieceCount > CurLev->PieceCount))
			{
				ReadRes();
			}
		}
	}
	else
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
			CurLev->PieceCount = piececount;
		}
		else if (d < CurLev->Rate)
		{
			CurLev->Rate = d;
			CurLev->PieceCount = piececount;
		}
		else if (d == CurLev->Rate &&
			(CurLev->PieceCount == -1 ||
			 CurLev->PieceCount < piececount))
		{
			CurLev->PieceCount = piececount;
		}
	}
};

void RateLev0B()
{
	int d;
	if (BCount == 0)
	{
		d = 300 - CurLev->LevNr;
	}
	else if (WCount == 0)
	{
		d = -300 + CurLev->LevNr;
	}
	else
		d = WCount - BCount;

	if (CurLev->WhoGoes == 'b')
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
		}
		else if (d < CurLev->Rate)
		{
			CurLev->Rate = d;
		}
		if (CurLev->LevNr == 0)
		{
			if ((GotResult.Rate == -1000) || (CurLev->Rate < GotResult.Rate))
			{
				ReadRes();
			}
		}
	}
	else
	{
		if (CurLev->Rate == 1000)
		{
			CurLev->Rate = d;
		}
		else if (d > CurLev->Rate)
		{
			CurLev->Rate = d;
		}
	}
};

void RateLev1A()
{
	if (CurLev->LevNr == 0)
	{
		return;
	}
	if (CurLev->Rate == 1000)
	{
		if (CurLev->WhoGoes == 'b')
		{
			CurLev->Rate = -200 + CurLev->LevNr;
		}
		else
        {
			CurLev->Rate = 200 - CurLev->LevNr;
		}
	}

	TLevel *cl = CurLev - 1;
	if (cl->Rate == 1000)
	{
		cl->Rate = CurLev->Rate;
	}
	else
	{
		if (CurLev->WhoGoes == 'b')
		{
			if (CurLev->Rate < cl->Rate)
			{
				cl->Rate = CurLev->Rate;
			}
		}
		else
		{
			if (CurLev->Rate > cl->Rate)
			{
				cl->Rate = CurLev->Rate;
			}
		}
	}
	if (CurLev->LevNr == 1)
	{
		int y1 = cl->OldPieceLn % 8 + 1;
		int x1 = cl->OldPieceLn / 8 + 1;
		int y2 = cl->CurPieceLn % 8 + 1;
		int x2 = cl->CurPieceLn / 8 + 1;
		TVarRec args[6] = {x1,y1,x2,y2,CurLev->Rate,CurLev->PieceCount};
		AnsiString s = AnsiString::Format("\n%d %d - %d %d r:%d pc:%d", args, 5);
		SHist += s;

		if (cl->Rate > GotResult.Rate)
		{
			ReadRes();
		}
	}
};

void RateLev1Ax()
{
	if (CurLev->LevNr == 0)
	{
		return;
	}
	if (CurLev->Rate == 1000)
	{
		if (CurLev->WhoGoes == 'b')
		{
			CurLev->Rate = -200 + CurLev->LevNr;
		}
		else
        {
			CurLev->Rate = 200 - CurLev->LevNr;
		}
		CurLev->PieceCount = BCount + WCount;
	}

	TLevel *cl = CurLev - 1;
	if (cl->Rate == 1000)
	{
		cl->Rate = CurLev->Rate;
		cl->PieceCount = CurLev->PieceCount;
	}
	else
	{
		if (CurLev->WhoGoes == 'b')
		{
			if (CurLev->Rate < cl->Rate)
			{
				cl->Rate = CurLev->Rate;
				cl->PieceCount = CurLev->PieceCount;
			}
			else if (CurLev->Rate == cl->Rate &&
				(cl->PieceCount == -1 ||
				cl->PieceCount < CurLev->PieceCount))
			{
				cl->PieceCount = CurLev->PieceCount;
			}
		}
		else
		{
			if (CurLev->Rate > cl->Rate)
			{
				cl->Rate = CurLev->Rate;
				cl->PieceCount = CurLev->PieceCount;
			}
			else if (CurLev->Rate == cl->Rate &&
				(cl->PieceCount == -1 ||
				cl->PieceCount > CurLev->PieceCount))
			{
				cl->PieceCount = CurLev->PieceCount;
			}
		}
	}
	if (CurLev->LevNr == 1)
	{
		int y1 = cl->OldPieceLn % 8 + 1;
		int x1 = cl->OldPieceLn / 8 + 1;
		int y2 = cl->CurPieceLn % 8 + 1;
		int x2 = cl->CurPieceLn / 8 + 1;
		TVarRec args[6] = {x1,y1,x2,y2,CurLev->Rate,CurLev->PieceCount};
		AnsiString s = AnsiString::Format("\n%d %d - %d %d r:%d pc:%d", args, 5);
		SHist += s;

		if (cl->Rate > GotResult.Rate)
		{
			ReadRes();
		}
		else if (cl->Rate == GotResult.Rate &&
			cl->PieceCount > -1 &&
			(GotResult.PieceCount == -1 ||
			cl->PieceCount < GotResult.PieceCount))
		{
			ReadRes();
		}
	}

};

void RateLev1B()
{
	if (CurLev->LevNr == 0)
	{
		return;
	}
	if (CurLev->Rate == 1000)
	{
		if (CurLev->WhoGoes == 'b')
		{
			CurLev->Rate = -200 + CurLev->LevNr;
		}
		else
			CurLev->Rate = 200 - CurLev->LevNr;
	}

	TLevel *cl = CurLev - 1;
	if (cl->Rate == 1000)
	{
		cl->Rate = CurLev->Rate;
	}
	else
	{
		if (CurLev->WhoGoes == 'b')
		{
			if (CurLev->Rate > cl->Rate)
			{
				cl->Rate = CurLev->Rate;
			}
		}
		else
		{
			if (CurLev->Rate < cl->Rate)
			{
				cl->Rate = CurLev->Rate;
			}
		}
	}
	if (CurLev->LevNr == 1)
	{
		if ((cl->Rate < GotResult.Rate) || (GotResult.Rate == -1000))
		{
			ReadRes();
		}
	}


};

bool RateLev2A()
{
	if (CurLev->LevNr == 0)
	{
		return false;
	}
	if (CurLev->Rate == 1000)
	{
		return false;
	}
	if (CurLev->RateA == 1000)
	{
		return false;
	}
	if (CurLev->WhoGoes == 'b')
	{
		return (CurLev->Rate > CurLev->RateA);
	}
	else
		return (CurLev->Rate < CurLev->RateA);
};

bool RateLev2B()
{
	if (CurLev->LevNr == 0)
	{
		return false;
	}
	if (CurLev->Rate == 1000)
	{
		return false;
	}
	if (CurLev->RateA == 1000)
	{
		return false;
	}
	if (CurLev->WhoGoes == 'b')
	{
		return (CurLev->Rate < CurLev->RateA);
	}
	else
		return (CurLev->Rate > CurLev->RateA);
};

void SetGameType(bool giveaway)
{
	if (giveaway)
	{
		RateLev0 = RateLev0B;
		RateLev1 = RateLev1B;
		RateLev2 = RateLev2B;
	}
	else
	{
		if(Random(10) < 5)
		{
			RateLev0 = RateLev0A;
			RateLev1 = RateLev1A;
			RateLev2 = RateLev2A;
		}
		else
		{
			RateLev0 = RateLev0Ax;
			RateLev1 = RateLev1Ax;
			RateLev2 = RateLev2A;
		}
	};
};

void backlev(bool &rez)
{
	rez = true;
	if (CurLev->LevNr == 0)
	{
		return;
	}
	rez = false;
	RateLev1();
	CurLev--;

	if (RateLev2())
	{
		// ShowMessage("a");
		GameGMCount++;
		GoM(rez);
		backlev(rez);
	};

};

void nextlev1(bool &rez)
{
	int i, k;

	rez = true;
	if ((BCount == 0) || (WCount == 0))
	{
		RateLev0();
		return;
	};
	if (CurLev->LevNr >= MaxLev)
	{
		dCanBeetX(CurLev->ZWhoGoes, k);
		if (k > 0)
		{
			rez = false;
			i = CurLev->Rate;
			CurLev++;
			CurLev->MKN = k;
			CurLev->CurPieceNr = 0;
			CurLev->CurPieceLn = -1;
			CurLev->MovesCount = 0;
			CurLev->Rate = 1000;
			CurLev->RateA = i;
			CurLev->Beet = true;
			CurLev->PieceCount = -1;
			return;
		};

		RateLev0();
		return;

	};

	rez = false;
	i = CurLev->Rate;
	CurLev++;
	CurLev->CurPieceNr = 0;
	CurLev->MKN = 0;
	CurLev->CurPieceLn = -1;
	CurLev->MovesCount = 0;
	CurLev->Rate = 1000;
	CurLev->RateA = i;
	CurLev->PieceCount = -1;
	dCanBeet(k);
	if (k > 0)
	{
		CurLev->Beet = true;
		CurLev->MKN = k;
	}
	else
		CurLev->Beet = false;

};

void nextlev2(bool &rez)
{
	bool o;
	int i;

	rez = true;
	if ((BCount == 0) || (WCount == 0))
	{
		RateLev0();
		return;
	};
	if (CurLev->LevNr >= MaxLev)
	{
		RateLev0();
		return;
	};

	rez = false;
	i = CurLev->Rate;
	CurLev++;
	CurLev->CurPieceNr = 0;
	CurLev->MKN = 0;
	CurLev->CurPieceLn = -1;
	CurLev->MovesCount = 0;
	CurLev->Rate = 1000;
	CurLev->RateB = 1000;
	CurLev->RateA = i;
	CurLev->PieceCount = -1;
	dCanBeet(i);
	if (i > 0)
	{
		CurLev->Beet = true;
		CurLev->MKN = i;
	}
	else
		CurLev->Beet = false;
};

bool IsGameFull(char c)
{
	bool o;
	int k;
	CanGoXX(c, o);
	if (o)
	{
		return false;
	}
	dCanBeetX(c, k);
	return (k == 0);
};

void MakeGRStr(AnsiString &s)
{
	s = IntToStr(GotResult.Rate) +
		" nr " + IntToStr(GotResult.CurPieceNr) +
		" onr:" + IntToStr(GotResult.OldPieceLn) +
		" v:" + IntToStr(GotResult.MoveV) +
		" vn:" + IntToStr(GotResult.MVN) +
		"\nn:" + IntToStr(TestedMovesCount) +
		"\nt:" + FloatToStrF(float(GameTickCount) / 1000, ffFixed, 6, 2) +
		"\out:" + IntToStr(GoOutCt) +
		"\nml:" + IntToStr(MaxLev);
};

void Restore()
{
	int i, j;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			l[i][j] = ol[i][j];
		}
	}
	for (i = 1; i < 13; i++)
	{
		m[i] = om[i];
		b[i] = ob[i];
	};
};

void Backup()
{
	int i, j;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			ol[i][j] = l[i][j];
		}
	}
	for (i = 1; i < 13; i++)
	{
		om[i] = m[i];
		ob[i] = b[i];
	};
};

void FindIt()
{
	bool o, pn, pb;
	int k, k1, k2;
	bool bGoOut;

	InitGame();
	TestedMovesCount = 0;
	StopThinking = false;

	GameTickCount = GetTickCount();

	SHist = "";

	pb = false;

	k = GetTickCount();
	bGoOut = false;

	do
	{
		Go(o);

		// AfterMove();

		if (o)
		{
			backlev(pb);

			if (CurLev->LevNr < MaxLev - 3)
			{
				k1 = GetTickCount();
				if (bGoOut)
				{
					if (k1 - k2 > 1200)
					{
						if (MaxLev > 3)
						{
							MaxLev--;
						}
						k2 = k1;
						GoOutCt++;
					}
				}
				else
				{
					if (k1 - k > 5000)
					{
						bGoOut = true;
						k2 = k1;
						if (MaxLev > 12)
						{
							MaxLev = MaxLev - 3;
						}
						else if (MaxLev > 7)
						{
							MaxLev = MaxLev - 2;
						}
						else if (MaxLev > 3)
						{
							MaxLev--;
						}
						GoOutCt++;
					};
				};
			};
		}
		else
		{
			TestedMovesCount++;
			nextlev(pn);
		};

		if (HaveMessage)
		{
			if (StopThinking)
			{
				MaxLev = 1;
				HaveMessage = false;
			};
			if (ThinkFaster)
			{
				if (MaxLev > 3)
				{
					MaxLev--;
				}
				StopThinking = false;
				ThinkFaster = false;
				HaveMessage = false;
			};
		};

	}
	while (!pb);

	GameTickCount = GetTickCount() - GameTickCount;

};

void FindItX()
{
	int i, k, k1, gx;
	float f1, f2;

	Randomize();
	StirUp();
	StopThinking = false;
	ThinkFaster = false;
	HaveMessage = false;

	GoOutCt = 0;
	gx = GetTickCount();

	MaxLev = 0;
	StartMaxLev = 0;
	nextlev = nextlev2;
	FindIt();

	TestedMovesCountX = TestedMovesCount;
	if (TestedMovesCount == 1)
	{
		return;
	}
	TimeMin = 4000;

	MaxLev = 1;
	nextlev = nextlev1;
	FindIt();

	k = GameTickCount;
	k1 = k;
	for (i = 1; i < 8; i++)
	{
		if (StopThinking)
		{
			return;
		}
		if ((k > TimeMin) || (GotResult.Rate > 100))
		{
			return;
		}
		if (k > 500)
		{
			break;
		}
		MaxLev++;
		k1 = k;
		FindIt();
		k = GameTickCount;
		TestedMovesCountX += TestedMovesCount;
		GameTickCountX = GetTickCount() - gx;
		if ((k1 == k) && (k > 50))
		{
			return;
		}
	};
	k = GameTickCount;
	StartMaxLev = MaxLev;

	f1 = k1;
	f2 = k;
	if (f1 == 0)
	{
		f1 = 5;
	}
	else
		f1 = f2 / f1;

	if (f2 == 0)
	{
		f2 = 1000;
	}

	TimeMin = 4000;
	MaxLev = ceil(log((float)TimeMin) / log(f2) * MaxLev) - 1;

	if (MaxLev > 16)
	{
		MaxLev = 16;
	}
	QChecked = true;

	if (StartMaxLev >= MaxLev)
	{
		if (GameTickCountX > 2000)
		{
			return;
		}
		MaxLev = StartMaxLev + 1;
	};

	StartMaxLev = MaxLev;

	GameGMCount = 0;
	FindIt();

	TestedMovesCountX += TestedMovesCount;
	GameTickCountX = GetTickCount() - gx;

	for (i = 1; i < 16; i++)
	{
		if (StopThinking)
		{
			return;
		}
		if ((GameTickCount > 2000) || (GotResult.Rate > 100))
		{
			break;
		}

		if (GameTickCountX > 4000)
		{
			break;
		}
		if (GoOutCt > 0)
		{
			break;
		}
		if (!QChecked)
		{
			break;
		}

		MaxLev++;
		FindIt();
		GameTickCountX = GetTickCount() - gx;
		TestedMovesCountX += TestedMovesCount;
	};

};

bool SetLWB(int x, int y, char c, bool q)
{
	int ln = FieldXYB[x][y].n;
	if ((x + y) % 2 == 0)
	{
		return false;
	}
	char c1;
	bool q1;
	TCell &ll = l[x][y];

	c1 = ll.C;
	q1 = ll.Q;
	if ((c1 == c) && (q1 == q))
	{
		return false;
	}

	TPiece *f1;
	if (c1 != ' ')
	{
		f1 = GetKz(ll.N, ll.C);
		f1->ln = -1;
		ll = TCell0;
	};

	if (c == ' ')
	{
		return true;
	}

	int i;
	if (c == 'b')
	{
		for (i = 1; i < 13; i++)
		{
			f1 = &b[i];
			if (f1->ln == -1)
			{
				f1->ln = ln;
				f1->q = q;
				ll.C = 'b';
				ll.N = i;
				ll.Q = q;
				return true;
			};
		};
		return false;
	};
	if (c == 'm')
	{
		for (i = 1; i < 13; i++)
		{
			f1 = &m[i];
			if (f1->ln == -1)
			{
				f1->ln = ln;
				f1->q = q;
				ll.C = 'm';
				ll.N = i;
				ll.Q = q;
				return true;
			};
		};
		return false;
	};
	return false;
};

bool CanMovePiece(int x, int y)
{
	TCell &b1 = l[x][y];
	int v = -1, vn, ln1;
	int ln = FieldXYB[x][y].n;
	if (b1.C != CurLev->WhoGoes)
	{
		return false;
	}
	if (CurLev->MovesCount > 0)
	{
		if (CurLev->CurPieceLn != ln)
		{
			return false;
		}
	}
	if (CurLev->Beet)
	{
		if (b1.Q)
		{
			dCanBeet2X(ln, v, ln1);
			return (v != -1);
		};
		CanBeet2X(ln, -1, v);
		return (v != -1);
	};
	if (b1.Q)
	{
		vn = -1;
		dCanGo1X(ln, v, vn, ln1);
		return (vn != -1);
	};
	CanGo2X(ln, -1, v);
	return (v != -1);
};

void WillMovePiece(int x, int y)
{
	int ln = FieldXYB[x][y].n;
	TCell &b1 = l[x][y];
	CurLev->CurPieceNr = b1.N;
	CurLev->CurPieceLn = ln;
	CurLev->MovesCount = 1;

	CurLev->MoveRec[1].v0 = -1;
	CurLev->MoveRec[1].v = -1;
	CurLev->MoveRec[1].State = 0;
	CurLev->MoveRec[1].Ln0 = ln;

};

// ret 1..4
int GetV(int x0, int y0, int x1, int y1)
{
	int xd, yd;
	xd = x1 - x0;
	yd = y1 - y0;
	if (std::abs(xd) != std::abs(yd))
	{
		return 0;
	}
	if (xd == 0)
	{
		return 0;
	}
	xd = xd / std::abs(xd);
	yd = yd / std::abs(yd);
	int i;
	for (i = 1; i < 5; i++)
	{
		if ((dx[i] == xd) && (dy[i] == yd))
		{
			return i;
		}
	}
	return 0;
}

bool IsWayClear(int x, int y, int zx, int zy, int v)
{
	while (1)
	{
		x += dx[v];
		y += dy[v];
		if (!VXY(x, y))
		{
			return false;
		}
		if (l[x][y].C != ' ')
		{
			return false;
		}
		if ((x == zx) && (y == zy))
		{
			return true;
		}
	};
};

bool CanMovePieceTo(int x, int y, int zx, int zy)
{
	TCell &b1 = l[x][y];
	if (b1.C != CurLev->WhoGoes)
	{
		return false;
	}
	if (b1.N != CurLev->CurPieceNr)
	{
		return false;
	}
	int cln, ln, x1, y1, v0, v2, v3;
	int ln1, ln2;
	char c1 = CurLev->ZWhoGoes;
	bool o;
	int zln = FieldXYB[zx][zy].n;
	ln = FieldXYB[x][y].n;
	cln = CurLev->CurPieceLn;
	if (ln != cln)
	{
		return false;
	}
	v2 = GetV(x, y, zx, zy);
	if (v2 == 0)
	{
		return false;
	}

	if (CurLev->Beet)
	{
		if (b1.Q)
		{
			v0 = CurLev->MoveRec[CurLev->MovesCount].v0 + 1;
			if (CurLev->MovesCount > 1)
			{
				if (v0 == dd[v2])
				{
					return false;
				}
			}
			dCanBeet1X(ln, v2 - 1, ln1);
			if (ln1 == -1)
			{
				return false;
			}
			x1 = FieldAB[ln1].x;
			y1 = FieldAB[ln1].y;
			if (!IsWayClear(x1, y1, zx, zy, v2))
			{
				return false;
			}
			v3 = -1;
			dCanBeet3X(ln1, v2 - 1, v3, ln1, ln2);
			if (v3 == -1)
			{
				return true;
			}

			v3 = -1;
			dCanBeet2aX(zln, v2 - 1, v3, ln2);
			return (v3 > -1);
		};
		CanBeet1(x, y, v2, o);
		if (!o)
		{
			return false;
		}
		return (std::abs(zx - x) == 2);
	};
	if (b1.Q)
	{
		return IsWayClear(x, y, zx, zy, v2);
	}
	if (std::abs(zx - x) != 1)
	{
		return false;
	}
	CanGo1(x, y, v2, o);
	return o;

};

bool MovePieceTo(int x, int y, int zx, int zy, bool &o)
{
	if (!CanMovePieceTo(x, y, zx, zy))
	{
		return false;
	}
	TCell &b1 = l[x][y];
	TCell &b3 = l[zx][zy];

	int x1, y1, v2, v3 = 0;
	int ln, ln1, zln;
	char c1 = CurLev->ZWhoGoes;
	int &mc = CurLev->MovesCount;
	TPiece *f1;

	ln = FieldXYB[x][y].n;
	zln = FieldXYB[zx][zy].n;

	v2 = GetV(x, y, zx, zy);

	if (CurLev->Beet)
	{
		if (b1.Q)
		{
			dCanBeet1X(ln, v2 - 1, ln1);

			TCell &b2 = li[ln1];

			CurLev->CurPieceLn = zln;
			CurLev->MoveRec[mc].Ln0 = ln;

			CurLev->MoveRec[mc].v = v2 - 1;
			CurLev->MoveRec[mc].MoveC = b2;
			CurLev->MoveRec[mc].MoveP = CurLev->ZGbm[b2.N];

			CurLev->MovesCount++;
			CurLev->MoveRec[mc].Ln0 = -1;
			CurLev->MoveRec[mc].v = -1;
			CurLev->MoveRec[mc].v0 = v2 - 1;

			if (b1.C == 'b')
			{
				f1 = &b[b1.N];
				f1->ln = zln;
				f1 = &m[b2.N];
				f1->ln = -1;
				BCount--;
			}
			else
			{
				f1 = &m[b1.N];
				f1->ln = zln;
				f1 = &b[b2.N];
				f1->ln = -1;
				WCount--;
			}

			b3 = b1;
			b1 = TCell0;
			b2 = TCell0;

			v3 = 0;
			dCanBeet2aX(zln, v2 - 1, v3, ln1);
			o = (v3 == -1);

			return true;
		};

		x1 = x + dx[v2];
		y1 = y + dy[v2];
		TCell &b2 = l[x1][y1];

		CurLev->CurPieceLn = zln;
		CurLev->MoveRec[mc].Ln0 = ln;

		CurLev->MoveRec[mc].v = v2 - 1;
		CurLev->MoveRec[mc].MoveC = b2;
		CurLev->MoveRec[mc].MoveP = CurLev->ZGbm[b2.N];

		CurLev->MovesCount++;
		CurLev->MoveRec[mc].Ln0 = -1;
		CurLev->MoveRec[mc].v = -1;

		if (b1.C == 'b')
		{
			f1 = &b[b1.N];
			f1->ln = zln;
			f1 = &m[b2.N];
			f1->ln = -1;
			BCount--;
		}
		else
		{
			f1 = &m[b1.N];
			f1->ln = zln;
			f1 = &b[b2.N];
			f1->ln = -1;
			WCount--;
		}

		b3 = b1;
		b1 = TCell0;
		b2 = TCell0;

		CanBeet2X(zln, -1, v3);
		o = (v3 == -1);

		if (o)
		{
			if (FieldAB[CurLev->Gbm[b3.N].ln].y == CurLev->DMax)
			{
				CurLev->Gbm[b3.N].q = true;
				b3.Q = true;
			}
		};

		return true;
	};

	CurLev->CurPieceLn = zln;
	CurLev->OldPieceLn = ln;

	CurLev->MoveRec[mc].v = v2 - 1;

	CurLev->MovesCount++;

	if (b1.C == 'b')
	{
		f1 = &b[b1.N];
		f1->ln = zln;
	}
	else
	{
		f1 = &m[b1.N];
		f1->ln = zln;
	}

	b3 = b1;
	b1 = TCell0;

	if (FieldAB[CurLev->Gbm[b3.N].ln].y == CurLev->DMax)
	{
		CurLev->Gbm[b3.N].q = true;
		b3.Q = true;
	};

	o = true;
	return true;
};

void ProcessGotResult()
{

	int cx, cy, v0, v1 = 0;
	int cln, ln, zln, ln1, lnx, vn;
	int i;

	// AnsiString s1;
	// MakeGRStr(s1);
	// ShowMessage(s1);

	if (GotResult.CurPieceNr == 0)
	{
		return;
	}

	TPiece &f1 = b[GotResult.CurPieceNr];
	cln = f1.ln;
	cx = FieldAB[cln].x;
	cy = FieldAB[cln].y;

	BeforPM(cx, cy);

	ClearLev0();
	CurLev->CurPieceNr = GotResult.CurPieceNr;
	CurLev->CurPieceLn = cln;

	if (GotResult.Beet)
	{
		if (f1.q)
		{
			for (i = 1; i <= GotResult.MovesCount; i++)
			{
				ln = CurLev->CurPieceLn;
				v0 = GotResult.MoveRec[i].v0;
				v1 = GotResult.MoveRec[i].v;
				zln = GotResult.MoveRec[i].Ln1;

				lnx = GotResult.MoveRec[i].Lnx;

				switch (GotResult.MoveRec[i].State)
				{
				case 0:
					ln1 = GotResult.MoveRec[i].MoveP.ln;
					dBeetp2X(ln, ln1, v1);
					break;

				case 3:
					dBeetp1X(ln, zln);
					if (i + 1 < GotResult.MovesCount)
					{
						AfterPM();
					}
					break;

				case 31:
					dBeetp1X(ln, zln);
					if (i + 1 < GotResult.MovesCount)
					{
						AfterPM();
					}
					break;

				case 4:
					dBeetp1X(ln, lnx);
					AfterPM();
					dBeetp2X(lnx, zln, v1);
					break;

				};
			}
			return;
		};

		for (i = 1; i < GotResult.MovesCount; i++)
		{
			ln = CurLev->CurPieceLn;
			v0 = GotResult.MoveRec[i].v;
			if (i > 1)
			{
				AfterPM();
			}
			Beetp1X(ln, v0);
		};
		if (FieldAB[f1.ln].y == 7)
		{
			f1.q = true;
			li[f1.ln].Q = true;
		};
		return;
	};

	ln = CurLev->CurPieceLn;
	v0 = GotResult.MoveV;

	if (f1.q)
	{
		zln = GotResult.MLN;
		vn = GotResult.MVN;

		dGoDontBeetp1X(ln, zln, v0, vn);
		return;
	};

	GoDontBeetp1X(ln, v0);
	if (FieldAB[f1.ln].y == 7)
	{
		f1.q = true;
		li[f1.ln].Q = true;
	};
	return;
};

void CountPieces(int &w, int &b)
{
	w = CountWs();
	b = CountBs();
};

void BeforYouMove()
{
	CurLev = &Levels[1];
	CurLev->CurPieceNr = 0;
	CurLev->CurPieceLn = -1;
	CurLev->RateB = 1000;
	CurLev->Rate = 1000;
    CurLev->PieceCount = -1;
	CurLev->MovesCount = 0;

	BCount = CountBs();
	WCount = CountWs();
	CanBeetX(CurLev->Beet);
}

void ClearLev1()
{
	int i;
	CurLev = &Levels[1];
	CurLev->CurPieceNr = 0;
	CurLev->CurPieceLn = -1;
	CurLev->MKN = 0;
	CurLev->Beet = false;
	CurLev->RateB = 1000;
	CurLev->Rate = 1000;
	CurLev->RateA = 1000;
	CurLev->PieceCount = -1;
	CurLev->MovesCount = 0;

	BCount = CountBs();
	WCount = CountWs();
	dCanBeet(i);
	if (i > 0)
	{
		CurLev->Beet = true;
		CurLev->MKN = i;
	}
	else
		CurLev->Beet = false;

	GotResult.Beet = CurLev->Beet;
};

void ClearLev0()
{
	int i;
	CurLev = &Levels[0];
	CurLev->CurPieceNr = 0;
	CurLev->CurPieceLn = -1;
	CurLev->MKN = 0;
	CurLev->Beet = false;
	CurLev->RateB = 1000;
	CurLev->Rate = 1000;
	CurLev->RateA = 1000;
	CurLev->PieceCount = -1;
	CurLev->MovesCount = 0;

	BCount = CountBs();
	WCount = CountWs();
	WqCount = CountWqs();
	BqCount = CountBqs();
	dCanBeet(i);
	if (i > 0)
	{
		CurLev->Beet = true;
		CurLev->MKN = i;
	}
	else
		CurLev->Beet = false;

	GotResult.Beet = CurLev->Beet;
};

void InitGame()
{
	defl0();
	defmovesf();
	ClearLev0();
	ClearRes();
};

void DefPieces12()
{
	ClearBoard();
	defPieces();
	BCount = CountBs();
	WCount = CountWs();
};

void GetGameParams(int &tk, int &mv, int &mvx, int &ml, int &rv, int &rv1,
	int &ogct, int &sml, int &gm)
{
	tk = GameTickCount;
	mv = TestedMovesCount;
	mvx = TestedMovesCountX;
	ml = MaxLev;
	sml = StartMaxLev;
	rv = GotResult.Rate;
	rv1 = GotResult.RateB;
	ogct = GoOutCt;
	gm = GameGMCount;

}

void dCanBeetY(char c, bool &rez)
{
	int k;
	dCanBeetX(c, k);
	rez = (k > 0);
};
