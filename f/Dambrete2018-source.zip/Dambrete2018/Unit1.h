// ---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
// ---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <System.Win.ScktComp.hpp>

// ---------------------------------------------------------------------------

enum TEnumGst
{
	gst0, gstNone, gstEdit, gstStartGame, gstMove, gstDrop, gstThink,
	gstPlaying, gstCompsMove, gstYourMove, gstHesMove, gstSleep, gstYouMoved,
	gstStopGame, gstCheckServer, gstThinkingDone, gstConnecting, gstConnectedC,
	gstConnectedS, gstCantConnect, gstDisConnected, gstWaitForConnection,
	gstGotSignal, gstWaitinForSignal, gstYouWin, gstCompWins, gstHeWins
};

void AfterMoveZ();

class TGameThread : public TThread
{
public:
	TGameThread(void) : TThread(true)
	{
		FreeOnTerminate = true;
	};

	void __fastcall AfterMoveA(void)
	{
		AfterMoveZ();
	};

	void __fastcall AM(void)
	{
		Synchronize((TThreadMethod)&AfterMoveA);
	};

protected:
	virtual void __fastcall Execute(void);

};

class TForm1 : public TForm
{
__published: // IDE-managed Components
	TImage *imBW;
	TImage *imBB;
	TPanel *Panel1;
	TImage *imBoard;
	TImage *imMove;
	TImage *imBoard0;
	TImage *imBBq;
	TImage *imBWq;
	TStatusBar *StatusBar1;
	TPageControl *PageControl1;
	TTabSheet *tabPlay;
	TTabSheet *tabEdit;
	TSpeedButton *sbWhite;
	TSpeedButton *sbBlack;
	TSpeedButton *sbClear;
	TSpeedButton *sbQeen;
	TComboBox *cb1;
	TSpeedButton *sbSaveB;
	TSpeedButton *sbAddB;
	TSpeedButton *sbInsertB;
	TSpeedButton *sbdeleteB;
	TSpeedButton *cmClearBoard;
	TSpeedButton *cmShowB;
	TSpeedButton *cmFullB;
	TSpeedButton *cmThinkFaster;
	TSpeedButton *cmStopGame;
	TSpeedButton *cmSave;
	TSpeedButton *cmTurnBoard;
	TUpDown *upd1;
	TSpeedButton *cmSaveCB;
	TClientSocket *scClient;
	TServerSocket *scServer;
	TTabSheet *tabNetGame;
	TSpeedButton *cmConnect;
	TTabSheet *tabStartGame;
	TSpeedButton *cmStartGame;
	TSpeedButton *cmFullB1;
	TSpeedButton *sbImWhite;
	TSpeedButton *sbImBlack;
	TSpeedButton *cmItsMe;
	TSpeedButton *cmTurnBoard2;
	TSpeedButton *cmSwapSides;
	TComboBox *cbTimeLimit;
	TSpeedButton *cmStartGameB;
	TImage *imBY;
	TComboBox *cbHostList;
	TTimer *Timer1;
	TButton *Button1;
	TSpeedButton *cmGetServers;
	TSpeedButton *sbHistBack;
	TSpeedButton *sbHistForw;

	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall imBoardMouseDown(TObject *Sender, TMouseButton Button,
		TShiftState Shift, int X, int Y);
	void __fastcall imBoardMouseMove(TObject *Sender, TShiftState Shift,
		int X, int Y);
	void __fastcall imMoveMouseDown(TObject *Sender, TMouseButton Button,
		TShiftState Shift, int X, int Y);
	void __fastcall imMoveMouseMove(TObject *Sender, TShiftState Shift,
		int X, int Y);
	void __fastcall cmClearBoardClick(TObject *Sender);
	void __fastcall cmThinkFasterClick(TObject *Sender);
	void __fastcall cb1DropDown(TObject *Sender);
	void __fastcall cb1Click(TObject *Sender);
	void __fastcall cb1KeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall sbSaveBClick(TObject *Sender);
	void __fastcall sbAddBClick(TObject *Sender);
	void __fastcall sbInsertBClick(TObject *Sender);
	void __fastcall sbdeleteBClick(TObject *Sender);
	void __fastcall cmShowBClick(TObject *Sender);
	void __fastcall cmFullBClick(TObject *Sender);
	void __fastcall cmStartGameClick(TObject *Sender);
	void __fastcall PageControl1Changing(TObject *Sender, bool &AllowChange);
	void __fastcall PageControl1Change(TObject *Sender);
	void __fastcall cmSaveClick(TObject *Sender);
	void __fastcall cmStopGameClick(TObject *Sender);
	void __fastcall sbImWhiteClick(TObject *Sender);
	void __fastcall cmTurnBoardClick(TObject *Sender);
	void __fastcall upd1Click(TObject *Sender, TUDBtnType Button);
	void __fastcall cmSaveCBClick(TObject *Sender);
	void __fastcall scClientConnect(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall scClientDisconnect(TObject *Sender,
		TCustomWinSocket *Socket);
	void __fastcall scClientError(TObject *Sender, TCustomWinSocket *Socket,
		TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall scServerClientConnect(TObject *Sender,
		TCustomWinSocket *Socket);
	void __fastcall scServerClientDisconnect(TObject *Sender,
		TCustomWinSocket *Socket);
	void __fastcall scServerClientError(TObject *Sender,
		TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall cmConnectClick(TObject *Sender);
	void __fastcall scServerClientRead(TObject *Sender,
		TCustomWinSocket *Socket);
	void __fastcall scClientRead(TObject *Sender, TCustomWinSocket *Socket);
	void __fastcall cmItsMeClick(TObject *Sender);
	void __fastcall cmTurnBoard2Click(TObject *Sender);
	void __fastcall cmSwapSidesClick(TObject *Sender);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall cbTimeLimitClick(TObject *Sender);
	void __fastcall cmStartGameBClick(TObject *Sender);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall cmGetServersClick(TObject *Sender);
	void __fastcall upd1ChangingEx(TObject *Sender, bool &AllowChange, int NewValue,
          TUpDownDirection Direction);
	void __fastcall sbHistBackClick(TObject *Sender);
	void __fastcall sbHistForwClick(TObject *Sender);

protected:
	virtual void __fastcall WndProc(Messages::TMessage &Message);

private:
	TEnumGst fGameState;
	TEnumGst fGameStateX;
	bool FMDown;
	int FMDownX, FMDownY, FMDownCX, FMDownCY;
	int FMDownXp, FMDownYp;
	TRect FMDownR1, FMDownR2;
	TStringList *FBoardStrings;
	TStringList *FMovesHistory;
	bool FBSChanged;
	bool FGameInWay;
	bool FImWhite;
	bool StopGame;
	bool fTurnBoard;
	bool fConnected;
	bool fOnLineGame;
	int fYellowFX, fYellowFY;
	String fConnectTo;
	AnsiString fMovesDone;
	AnsiString fGotAnswer;
	int MyMSG;
	TCustomWinSocket *GotSocket;
	bool fServersListed;

	void __fastcall SetImWhite(bool value);
	void __fastcall SetTurnBoard(bool value);
	void __fastcall SetConnectTo(String s);
	void __fastcall FOnGTdone(TObject *Sender);

	void __fastcall SetYellowF(int i, int j);

	void __fastcall SetCellValue(int i, int j, char value);
	char __fastcall GetCellValue(int i, int j);

	void __fastcall SetImPic(TImage *M, char value);
	void __fastcall SetCellPic(int i, int j, int value);
	void __fastcall SetGameStateX(TEnumGst value);
	void __fastcall SetGameState(TEnumGst value);
	void MakeBoardStr(AnsiString &s);
	void DrawBoardStr(AnsiString s);
	void SetBoardStr(int n);
	void PaintPics();
	void RefreshPieceCount();
	void StartGameThread();
	void SendStr(AnsiString s);
	void CompWillMove();
	void AfterComp();
	bool OpenServer();
	void DoMuMSG();
	void GetMyServers(TStrings* sl);

	TRect fTickerRect;
	TEnumGst fTicerGSt;
	int fTickerCount;

	void __fastcall StartTicker(int x, int y);
	void __fastcall DoTicker();
	void __fastcall EndTicker();

public:
	TGameThread *fGameThread;
	bool FMoved;
	bool FDebug;
	char AIMValue[8][8];

	__fastcall TForm1(TComponent* Owner);
	void __fastcall SetBoard();
	void __fastcall GetCellRect(int i, int j, TRect &R);
	void __fastcall GetCellRectX(int i, int j, TRect &R);

	bool __fastcall IsInBoard(int x, int y);
	bool __fastcall IsInGCell(int i, int j);
	void __fastcall InCell(int i, int j, TPoint &p);
	bool __fastcall IsInCell(int x, int y, TPoint &p);
	bool __fastcall IsInCellX(int x, int y, TPoint &p);

	bool __fastcall CanMoveCell(int x, int y);
	bool __fastcall CanMoveCellTo(int x1, int y1, int x2, int y2);

	void __fastcall DrawBoard();
	void ClearCells();
	void LoadPics();
	void Connect();
	void PocessMovesString(AnsiString &s);
	void AfterPM();
	void BeforPM(int x, int y);
	void SleepX(int);
	void ShowStatus(int n, String s);

	__property bool ImWhite =
	{read = FImWhite, write = SetImWhite};
	__property bool TurnBoard =
	{read = fTurnBoard, write = SetTurnBoard};
	__property String ConnectTo =
	{read = fConnectTo, write = SetConnectTo};
	__property TEnumGst GameState =
	{read = fGameState, write = SetGameState};
	__property TEnumGst GameStateX =
	{read = fGameStateX, write = SetGameStateX};
	__property char CellValue[int i][int j] =
	{read = GetCellValue, write = SetCellValue};
};

// ---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
// ---------------------------------------------------------------------------
#endif
