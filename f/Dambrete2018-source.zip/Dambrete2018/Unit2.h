// ---------------------------------------------------------------------------
#ifndef Unit2H
#define Unit2H
// ---------------------------------------------------------------------------
//#include <stdlib.h>

#define FCALL
#define INL inline
#define VXY(x, y)  ( ((x) >= 0) && \
    ((x) < 8) && ((y) >= 0) && ((y) < 8) )

extern AnsiString SHist;

void InitGame();
void FindIt();
void FindItX();
void ClearBoard();
void DefPieces12();
bool SetLWB(int x, int y, char c, bool q);
bool IsGameFull(char c);
void dCanBeetY(char c, bool &rez);
void WillMovePiece(int x, int y);
bool CanMovePiece(int x, int y);
bool CanMovePieceTo(int x, int y, int zx, int zy);
bool MovePieceTo(int x, int y, int zx, int zy, bool &o);
void ProcessGotResult();
void AfterPM();
void BeforPM(int x, int y);
void GetGameParams(int &tk, int &mv, int &mvx, int &ml, int &rv, int &rv1,
	int &ogct, int &sml, int &gm);
void MakeGRStr(AnsiString &s);
void SwapSides();
void CountPieces(int &w, int &b);
void ClearLev0();
void ClearLev1();
void SetGameType(bool giveaway);

void AfterMove();

struct TCell
{
	char C;
	int N;
	int FN;
	bool Q;
};

const TCell& GetLxy(int x, int y);
TCell* GetL();

extern TCell TCell0;
extern bool FDLoop;
extern bool StopThinking;
extern bool ThinkFaster;
extern bool HaveMessage;
extern int TimeMin;

#endif
