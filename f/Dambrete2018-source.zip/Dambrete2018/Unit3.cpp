//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <ShellApi.h>
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm3::SpeedButton1Click(TObject *Sender)
{
 ShellExecute(0, NULL, L"mailto: aivars.ik@gmail.com", NULL, NULL, SW_NORMAL);
}
//---------------------------------------------------------------------------


void __fastcall TForm3::SpeedButton2Click(TObject *Sender)
{
 Close();
}

void __fastcall TForm3::WndProc(Messages::TMessage &Message)
{
 if(Message.Msg==WM_NCHITTEST) {

  if(ScreenToClient(Mouse->CursorPos).y<100) {
   Message.Result=HTCAPTION;
   return;
  }; 
 };
 TForm::WndProc(Message);
};

//---------------------------------------------------------------------------


