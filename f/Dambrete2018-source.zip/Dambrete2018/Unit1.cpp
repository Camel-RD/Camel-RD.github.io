// ---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <StdLib.h>
#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"

// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

int CellW = 40, CellH = 40;
int CurrentHistoryListPos = 0;
bool BlockMouseClick = false;

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner)
{
	Panel1->DoubleBuffered = true;
	FMDown = false;
}
// ---------------------------------------------------------------------------

void TForm1::PaintPics()
{
	TRect r;
	int i, j;
	imBoard->Canvas->Brush->Style = bsSolid;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			//r.Left = CellW * i;
			//r.Top = CellH * j;
			r.Left = (int)((double)i * (double)imBoard->Width / (double)8.0);
			r.Top = (int)((double)j * (double)imBoard->Height / (double)8.0);
			r.Right = r.Left + CellW;
			r.Bottom = r.Top + CellH;
			if ((i + j) % 2 == 1)
			{
				imBoard->Canvas->Brush->Color = TColor(RGB(232, 176, 40));
				imBoard->Canvas->FillRect(r);
			}
			else
			{
				imBoard->Canvas->Brush->Color = TColor(RGB(80, 160, 80));
				imBoard->Canvas->FillRect(r);
			};
		}
	};

	imBoard0->Canvas->Draw(0, 0, imBoard->Picture->Bitmap);

	imBB->Picture->Bitmap->Width = 50;
	imBB->Picture->Bitmap->Height = 50;
	imBB->Canvas->Brush->Style = bsSolid;
	imBB->Canvas->Pen->Style = psSolid;
	imBB->Canvas->Pen->Mode = pmCopy;
	imBB->Canvas->Pen->Width = 1; ;
	imBB->Canvas->Brush->Color = clRed;
	imBB->Canvas->FillRect(Rect(0, 0, 50, 50));
	imBB->Canvas->Pen->Color = TColor(RGB(0, 0, 0));
	imBB->Canvas->Brush->Color = TColor(RGB(0, 0, 0));
	imBB->Canvas->Ellipse(10, 10, 40, 40);

	imBW->Picture->Bitmap->Width = 50;
	imBW->Picture->Bitmap->Height = 50;
	imBW->Canvas->Brush->Style = bsSolid;
	imBW->Canvas->Brush->Color = clRed;
	imBW->Canvas->Pen->Color = TColor(RGB(255, 255, 255));
	imBW->Canvas->FillRect(Rect(0, 0, 50, 50));
	imBW->Canvas->Brush->Color = TColor(RGB(255, 255, 255));
	imBW->Canvas->Ellipse(10, 10, 40, 40);

	imBBq->Picture->Bitmap->Width = 50;
	imBBq->Picture->Bitmap->Height = 50;
	imBBq->Canvas->Brush->Color = clRed;
	imBBq->Canvas->Pen->Color = TColor(RGB(250, 0, 0));
	imBBq->Canvas->FillRect(Rect(0, 0, 50, 50));
	imBBq->Canvas->Brush->Color = TColor(RGB(0, 0, 0));
	imBBq->Canvas->Ellipse(10, 10, 40, 40);
	imBBq->Canvas->Brush->Style = bsClear;
	imBBq->Canvas->Pen->Color = clWhite;
	imBBq->Canvas->Pen->Width = 3;
	imBBq->Canvas->Ellipse(15, 15, 35, 35);

	imBWq->Picture->Bitmap->Width = 50;
	imBWq->Picture->Bitmap->Height = 50;
	imBWq->Canvas->Brush->Color = clRed;
	imBWq->Canvas->Pen->Color = TColor(RGB(250, 0, 0));
	imBWq->Canvas->FillRect(Rect(0, 0, 50, 50));
	imBWq->Canvas->Brush->Color = TColor(RGB(255, 255, 255));
	imBWq->Canvas->Ellipse(10, 10, 40, 40);
	imBWq->Canvas->Brush->Style = bsClear;
	imBWq->Canvas->Pen->Color = TColor(RGB(0, 0, 0));
	imBWq->Canvas->Pen->Width = 3;
	imBWq->Canvas->Ellipse(15, 15, 35, 35);
};

void TForm1::LoadPics()
{
	// Graphics::TBitmap *bm= new Graphics::TBitmap;
	String s;
	s = ExtractFilePath(Application->ExeName);

	// bm->LoadFromFile(s+"fa.bmp");
	// imBoard->Canvas->StretchDraw(imBoard->ClientRect,bm);

	imBoard->Canvas->StretchDraw(imBoard->ClientRect,
		imBoard0->Picture->Bitmap);
	imBoard0->Canvas->CopyRect(imBoard->ClientRect, imBoard->Canvas,
		imBoard0->ClientRect);

	// imBW->Picture->LoadFromFile(s+"bw.bmp");
	// imBB->Picture->LoadFromFile(s+"bb.bmp");
	// imBWq->Picture->LoadFromFile(s+"bwq.bmp");
	// imBBq->Picture->LoadFromFile(s+"bbq.bmp");

	// delete bm;
};

void __fastcall TForm1::SetBoard()
{
	ClearCells();

	try
	{
		LoadPics();
	}
	catch (...)
	{
		PaintPics();
	};

	ClearCells();

	imMove->Width = CellW;
	imMove->Height = CellH;
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
	//
	String s;
	s = ExtractFilePath(Application->ExeName) + u"sb.txt";
	if (FBSChanged)
	{
		try
		{
			FBoardStrings->SaveToFile(s);
		}
		catch (...)
		{
		};
	};
	delete FBoardStrings;
    delete FMovesHistory;
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	String s;
	CellW = imBoard->Width / 8;
	CellH = imBoard->Height / 8;
	fTurnBoard = false;
	InitGame();
	SetBoard();
	GotSocket = NULL;
	GameState = gstNone;
	fGameStateX = gst0;
	DefPieces12();
	fYellowFX = -1;
	fYellowFY = -1;
	DrawBoard();
	randomize();
	FGameInWay = false;
	FImWhite = false;
	TurnBoard = false;
	sbImBlack->Down = true;
	fConnected = false;
	fOnLineGame = false;
	fServersListed = false;
	FBoardStrings = new TStringList();
	FMovesHistory = new TStringList();
	s = ExtractFilePath(Application->ExeName) + u"sb.txt";
	try
	{
		FBoardStrings->LoadFromFile(s);
	}
	catch (...)
	{
	};
	FBSChanged = false;
	MyMSG = WM_APP + 111;
	cbTimeLimit->ItemIndex = 2;
	TimeMin = 3000;

};
// ---------------------------------------------------------------------------

bool TForm1::OpenServer()
{
	try
	{
		scServer->Open();
	}
	catch (...)
	{
		scServer->Port = 304;
		try
		{
			scServer->Open();
		}
		catch (...)
		{
			return false;
		};
	};
	return true;
};

void __fastcall TForm1::GetCellRect(int i, int j, TRect &R)
{
	//R.Left = i * CellW;
	//R.Top = j * CellH;
	R.Left = (int)((double)i * (double)imBoard->Width / (double)8.0);
	R.Top = (int)((double)j * (double)imBoard->Height / (double)8.0);
	R.Right = R.Left + CellW - 1;
	R.Bottom = R.Top + CellH - 1;
}

void __fastcall TForm1::GetCellRectX(int i, int j, TRect &R)
{
	if (TurnBoard)
	{
		i = 7 - i;
		j = 7 - j;
	};
	R.Left = (int)((double)i * (double)imBoard->Width / (double)8.0);
	R.Top = (int)((double)j * (double)imBoard->Height / (double)8.0);
	R.Right = R.Left + CellW - 1;
	R.Bottom = R.Top + CellH - 1;
}

void __fastcall TForm1::SetYellowF(int i, int j)
{
	int x, y;
	x = fYellowFX;
	y = fYellowFY;
	if (x != -1)
	{
		// fYellowFX=-1;
		// fYellowFY=-1;
		SetCellPic(x, y, AIMValue[x][y]);
	};
	fYellowFX = i;
	fYellowFY = j;
	if (i != -1)
	{
		SetCellPic(i, j, AIMValue[i][j]);
	}
};

void __fastcall TForm1::SetCellPic(int i, int j, int value)
{
	TRect R;
	GetCellRectX(i, j, R);
	imBoard->Canvas->CopyRect(R, imBoard0->Canvas, R);
	if (i == fYellowFX && j == fYellowFY)
	{
		imBoard->Canvas->StretchDraw(R, imBY->Picture->Graphic);
		return;
	};
	switch (value)
	{
	case 'm':
		imBoard->Canvas->StretchDraw(R, imBB->Picture->Graphic);
		break;
	case 'b':
		imBoard->Canvas->StretchDraw(R, imBW->Picture->Graphic);
		break;
	case 'M':
		imBoard->Canvas->StretchDraw(R, imBBq->Picture->Graphic);
		break;
	case 'B':
		imBoard->Canvas->StretchDraw(R, imBWq->Picture->Graphic);
		break;
	}

}

void __fastcall TForm1::SetImPic(TImage *M, char value)
{
	switch (value)
	{
	case 'b':
		M->Picture = imBW->Picture;
		break;
	case 'm':
		M->Picture = imBB->Picture;
		break;
	case 'B':
		M->Picture = imBWq->Picture;
		break;
	case 'M':
		M->Picture = imBBq->Picture;
		break;
	}
}

void __fastcall TForm1::SetTurnBoard(bool value)
{
	if (value == fTurnBoard)
		return;
	ClearCells();
	fTurnBoard = value;
	DrawBoard();
	cmTurnBoard->Down = value;
	cmTurnBoard2->Down = value;
};

void __fastcall TForm1::SetCellValue(int i, int j, char value)
{
	if (FImWhite)
	{
		switch (value)
		{
		case 'b':
			value = 'm';
			break;
		case 'm':
			value = 'b';
			break;
		case 'B':
			value = 'M';
			break;
		case 'M':
			value = 'B';
			break;
		}
	};
	if (AIMValue[i][j] == value)
		return;
	AIMValue[i][j] = value;
	SetCellPic(i, j, value);
}

char __fastcall TForm1::GetCellValue(int i, int j)
{
	return AIMValue[i][j];

}

bool __fastcall TForm1::IsInBoard(int i, int j)
{
	return ((i > 0) && (i < imBoard->Width) && (j > 0) && (j <
		imBoard->Height));
}

void __fastcall TForm1::InCell(int x, int y, TPoint &p)
{
	p.x = x / CellW;
	p.y = y / CellH;
}

bool __fastcall TForm1::IsInGCell(int i, int j)
{
	return ((i + j) % 2 == 1);
}

bool __fastcall TForm1::IsInCell(int x, int y, TPoint &p)
{
	if (!IsInBoard(x, y))
		return false;
	TPoint p1;
	InCell(x, y, p1);
	if ((p1.x + p1.y) % 2 == 0)
		return false;
	p = p1;
	return true;
}

bool __fastcall TForm1::IsInCellX(int x, int y, TPoint &p)
{
	if (!IsInBoard(x, y))
		return false;
	TPoint p1;
	InCell(x, y, p1);
	if ((p1.x + p1.y) % 2 == 0)
		return false;
	p = p1;
	if (TurnBoard)
	{
		p.x = 7 - p.x;
		p.y = 7 - p.y;
	};
	return true;
}

bool __fastcall TForm1::CanMoveCell(int x, int y)
{
	return CanMovePiece(x, y);
}

bool __fastcall TForm1::CanMoveCellTo(int x1, int y1, int x2, int y2)
{
	return CanMovePieceTo(x1, y1, x2, y2);
}

void TForm1::PocessMovesString(AnsiString &s)
{
	int i, n, x1, y1, x2, y2;
	bool o;
	ClearLev0();
	x1 = 7 - StrToInt(s[1]);
	y1 = 7 - StrToInt(s[2]);
	WillMovePiece(x1, y1);
	BeforPM(x1, y1);
	n = s.Length() / 2 - 1;
	for (i = 1; i <= n; i++)
	{
		x2 = 7 - StrToInt(s[i * 2 + 1]);
		y2 = 7 - StrToInt(s[i * 2 + 2]);
		MovePieceTo(x1, y1, x2, y2, o);
		AfterPM();
		x1 = x2;
		y1 = y2;
	};
};

void __fastcall TForm1::imBoardMouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
	TPoint r;
	if (!IsInCellX(X, Y, r))
		return;

	if (GameState == gstEdit)
	{
		char c = ' ', c1;
		if (sbWhite->Down)
			c = 'b';
		if (sbBlack->Down)
			c = 'm';
		if (FImWhite && (c != ' '))
		{
			c = (c == 'b') ? 'm' : 'b';
		}
		c1 = c;
		if (c1 == 'b' && sbQeen->Down)
			c1 = 'B';
		if (c1 == 'm' && sbQeen->Down)
			c1 = 'M';
		if (SetLWB(r.x, r.y, c, sbQeen->Down))
		{
			CellValue[r.x][r.y] = c1;
		}
		return;
	};

	if (GameState == gstMove)
	{
        if(BlockMouseClick) return;
		FMDownCX = r.x;
		FMDownCY = r.y;
		ClearLev1();
		if (!CanMoveCell(FMDownCX, FMDownCY))
			return;
		WillMovePiece(FMDownCX, FMDownCY);
		fMovesDone = IntToStr(FMDownCX) + IntToStr(FMDownCY);
		GetCellRectX(FMDownCX, FMDownCY, FMDownR1);
		FMDownX = (FMDownR1.Left + FMDownR1.Right) / 2;
		FMDownY = (FMDownR1.Top + FMDownR1.Bottom) / 2;
		Mouse->CursorPos = imBoard->ClientToScreen(Point(FMDownX, FMDownY));
		SetYellowF(FMDownCX, FMDownCY);
		FMDown = true;
		FMDownR2 = FMDownR1;
		if (GetLxy(FMDownCX, FMDownCY).Q)
		{
			if (ImWhite)
				SetImPic(imMove, 'B');
			else
				SetImPic(imMove, 'M');
		}
		else if (ImWhite)
			SetImPic(imMove, 'b');
		else
			SetImPic(imMove, 'm');
		imMove->Left = imBoard->Left + FMDownR1.Left;
		imMove->Top = imBoard->Top + FMDownR1.Top;
		imMove->Visible = true;
		imMove->Refresh();
		GameState = gstDrop;
		SetCaptureControl(imMove);
	};

	if (GameState == gstDrop)
	{
		bool o;
		if (!CanMovePieceTo(FMDownCX, FMDownCY, r.x, r.y))
		{
			return;
		}
		MovePieceTo(FMDownCX, FMDownCY, r.x, r.y, o);
		FMDownCX = r.x;
		FMDownCY = r.y;
		fMovesDone += IntToStr(FMDownCX) + IntToStr(FMDownCY);
		if (o)
		{
			imMove->Hide();
			FMDown = false;
			FMoved = true;
			ReleaseCapture();
			SetYellowF(-1, -1);
			DrawBoard();
			GameState = gstYouMoved;
			return;
		};
		SetYellowF(FMDownCX, FMDownCY);
		DrawBoard();
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::imBoardMouseMove(TObject *Sender, TShiftState Shift,
	int X, int Y)
{
	if (!FMDown)
		return;
	if (GameState == gstDrop)
	{
		FMDownR2.Left = FMDownR1.Left + X - FMDownX;
		FMDownR2.Top = FMDownR1.Top + Y - FMDownY;
		if (FMDownR2.Left < 0)
			FMDownR2.Left = 0;
		if (FMDownR2.Top < 0)
			FMDownR2.Top = 0;
		if (FMDownR2.Left > 7 * CellW)
			FMDownR2.Left = 7 * CellW;
		if (FMDownR2.Top > 7 * CellH)
			FMDownR2.Top = 7 * CellH;

		imMove->Left = imBoard->Left + FMDownR2.Left;
		imMove->Top = imBoard->Top + FMDownR2.Top;
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::imMoveMouseDown(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
	if (!FMDown)
		return;
	if (GameState == gstDrop)
	{
		imBoardMouseDown(imBoard, Button, Shift,
			imMove->Left + X - imBoard->Left, imMove->Top + Y - imBoard->Top);
	};
};

void __fastcall TForm1::imMoveMouseMove(TObject *Sender, TShiftState Shift,
	int X, int Y)
{
	if (!FMDown)
		return;
	if (GameState == gstDrop)
	{
		imBoardMouseMove(imBoard, Shift, imMove->Left + X - imBoard->Left,
			imMove->Top + Y - imBoard->Top);
	};
};

void __fastcall TForm1::DrawBoard()
{
	int i, j, x, y;
	char c;
	TCell* lx = GetL();
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			x = i;
			y = j;

			c = lx[x * 8 + y].C;
			if (lx[x * 8 + y].Q && c == 'b')
				c = 'B';
			if (lx[x * 8 + y].Q && c == 'm')
				c = 'M';

			CellValue[x][y] = c;
		}
	}
    delete lx;
	RefreshPieceCount();
}

void __fastcall TForm1::cmClearBoardClick(TObject *Sender)
{
	ClearBoard();
	DrawBoard();
};

// ---------------------------------------------------------------------------

void TForm1::SleepX(int ms)
{
	long i;
	TEnumGst f;
	f = fGameState;
	fGameState = gstSleep;

	i = GetTickCount();
	do
	{
		Application->ProcessMessages();
	}
	while ((int)GetTickCount() - i < ms);
	fGameState = f;
};

void TForm1::AfterPM()
{
	Form1->DrawBoard();
	Application->ProcessMessages();
	Form1->SleepX(1000);
};

void AfterPM()
{
	Form1->AfterPM();
};

void AfterMoveZ()
{
	// if(Form1->ch1->Checked)
	Form1->DrawBoard();
	Form1->FDebug = true;
	while (Form1->FDebug)
	{
		Application->ProcessMessages();
		if (Application->Terminated)
			return;
	};
	FDLoop = false;

};

void AfterMove()
{
	Form1->fGameThread->AM();
};

void TForm1::BeforPM(int x, int y)
{
	// StartTicker(x,y);
	// return;

	int i;
	TRect r;
	TEnumGst f;
	f = fGameState;
	fGameState = gstSleep;

	Form1->DrawBoard();
	Application->ProcessMessages();
	Form1->GetCellRectX(x, y, r);
	for (i = 1; i < 3; i++)
	{
		Form1->imBoard->Canvas->Pen->Mode = pmNot;
		Form1->imBoard->Canvas->Rectangle(r.Left, r.Top, r.Right, r.Bottom);
		Application->ProcessMessages();
		SleepX(1000);
	};
	Form1->imBoard->Canvas->Pen->Mode = pmCopy;
	fGameState = f;
};

void BeforPM(int x, int y)
{
	Form1->BeforPM(x, y);
};

void TForm1::ShowStatus(int n, String s)
{
	StatusBar1->Panels->Items[n]->Text = s;
};

void TForm1::RefreshPieceCount()
{
	int w, b, i;
	CountPieces(w, b);
	if (FImWhite)
	{
		i = w;
		w = b;
		b = i;
	};
	ShowStatus(2, u"B: " + IntToStr(w));
	ShowStatus(3, u"M: " + IntToStr(b));
};

void TForm1::CompWillMove()
{
	ThinkFaster = false;
	StopGame = false;
	StopThinking = false;
	InitGame();
	ShowStatus(1, u"");

	if (IsGameFull('b'))
	{
		FGameInWay = false;
		GameState = gstYouWin;
		return;
	};
	GameState = gstThink;
	StartGameThread();

};

void __fastcall TForm1::SetGameStateX(TEnumGst value)
{
	switch (value)
	{
	case gstStopGame:
		if (GameState == gstThink)
		{
			StopGame = true;
			StopThinking = true;
			HaveMessage = true;
			return;
		};
		if (GameState != gstSleep)
		{
			GameState = value;
		};
		break;

	case gstThinkingDone:
		if (fGameState == gstThink)
		{
			GameState = value;
			return;
		};
		break;

	case gstDisConnected:
		if (FGameInWay)
		{
			GameState = value;
			return;
		};
		break;

	case gstGotSignal:
		if (GameState == gstHesMove)
		{
			GameState = value;
			return;
		};
		break;

	case gstCheckServer:
		int i;
		for (i = 0; i < scServer->Socket->ActiveConnections; i++)
		{
			if (scServer->Socket->Connections[i] != GotSocket)
			{
				scServer->Socket->Connections[i]->Close();
			}
		}
		break;

	default:
		GameState = value;
		return;

	};

};

void __fastcall TForm1::SetGameState(TEnumGst value)
{
	bool o;
	fGameState = value;
	AnsiString sb = "";
	ShowStatus(0, "");
	switch (fGameState)
	{

	case gstNone:
		imMove->Hide();
		tabPlay->TabVisible = false;
		tabEdit->TabVisible = true;
		tabStartGame->TabVisible = true;
		tabNetGame->TabVisible = true;
		scServer->Close();
		scClient->Close();
		fOnLineGame = false;
		FGameInWay = false;
		fConnected = false;
		PageControl1->ActivePage = tabStartGame;
		break;

	case gstEdit:
		PageControl1->ActivePage = tabEdit;
		ShowStatus(0, u"Labot");
		scServer->Close();
		scClient->Close();
		fConnected = false;
		break;

	case gstStartGame:
		tabPlay->TabVisible = true;
		tabEdit->TabVisible = false;
		tabStartGame->TabVisible = false;
		tabNetGame->TabVisible = false;
		PageControl1->ActivePage = tabPlay;
		if (FImWhite)
			SetImPic(imMove, 'b');
		else
			SetImPic(imMove, 'm');
        FMovesHistory->Clear();
		Application->ProcessMessages();
		FGameInWay = true;
		if (FImWhite)
			GameState = gstYourMove;
		else if (fOnLineGame)
			GameState = gstHesMove;
		else
			GameState = gstCompsMove;

		break;

	case gstStopGame:
		imMove->Hide();
		StatusBar1->Panels->Items[1]->Text = "";
		ShowMessage("Sp�le aptur�ta");
		FGameInWay = false;
		fOnLineGame = false;
		GameState = gstNone;
		break;

	case gstYourMove:
		if (IsGameFull('m'))
		{
			ShowMessage("Kompis uzvar!");
			FGameInWay = false;
			GameState = gstNone;
			return;
		};

		dCanBeetY('m', o);
		if (o)
			ShowStatus(0, "Tev j�sit");
		else
			ShowStatus(0, "Tev j�iet");

		FMoved = false;
		ClearLev1();
		MakeBoardStr(sb);
		FMovesHistory->Add(sb);
		CurrentHistoryListPos = FMovesHistory->Count - 1;
		BlockMouseClick = false;
		fGameState = gstMove;
		break;

	case gstYouMoved:
		if (fOnLineGame)
		{
			SendStr(fMovesDone);
			GameState = gstHesMove;
		}
		else
		{
			if(CurrentHistoryListPos < FMovesHistory->Count - 1)
			{
				for(int i = FMovesHistory->Count - 1; i > CurrentHistoryListPos; i--)
					FMovesHistory->Delete(i);
			}
			MakeBoardStr(sb);
			FMovesHistory->Add(sb);
			CurrentHistoryListPos = FMovesHistory->Count - 1;
			GameState = gstCompsMove;
		}
		break;

	case gstCompsMove:
		CompWillMove();
		break;

	case gstThinkingDone:
		if (StopGame)
		{
			GameState = gstStopGame;
			return;
		};
		AfterComp();
		GameState = gstYourMove;
		break;

	case gstThink:
		ShowStatus(0, "Kompis dom�");
		break;

	case gstHesMove:
		if (IsGameFull('m'))
		{
			ShowMessage("Tava uzvara!");
			FGameInWay = false;
			GameState = gstNone;
			return;
		};
		ShowStatus(0, "Gaidam atbildi");
		break;

	case gstGotSignal:
		ShowStatus(0, "Sa�emta atbilde");
		if (!fConnected)
		{
			GameState = gstStopGame;
			return;
		};
		PocessMovesString(fGotAnswer);
		DrawBoard();
		GameState = gstYourMove;
		break;

	case gstWaitForConnection:
		ShowStatus(0, "Gaidam piesl�gumu");
		DefPieces12();
		DrawBoard();
		if (!OpenServer())
		{
			ShowMessage("Neizdev�s atv�rt serveri");
			GameState = gstNone;
		};
		break;

	case gstConnecting:
		ShowStatus(0, "M��inam piesl�gties");
		break;

	case gstConnectedC:
		ShowStatus(0, "Piesl�dz�mies");
		ImWhite = true;
		fOnLineGame = true;
		GameState = gstStartGame;
		break;

	case gstConnectedS:
		ShowStatus(0, "Piesl�dz�mies");
		ImWhite = false;
		fOnLineGame = true;
		GameState = gstStartGame;
		break;

	case gstCantConnect:
		ShowStatus(0, "Neizdev�s piesl�gties");
		fOnLineGame = false;
		GameState = gstNone;
		break;

	case gstDisConnected:
		ShowStatus(0, "Otrs atsl�dz�s");
		fOnLineGame = false;
		GameState = gstStopGame;
		break;

	case gstYouWin:
		ShowMessage("Tava uzvara");
		GameState = gstNone;
		break;

	};

};

void TForm1::AfterComp()
{
	int tk, mv, mvx, ml, rv, rv1, gm, sml, ogct;
	String s;

	//ShowMessage(SHist);

	GetGameParams(tk, mv, mvx, ml, rv, rv1, ogct, sml, gm);
	// StatusBar1->Panels->Items[1]->Text="n: "
	// +IntToStr(mv);
	// StatusBar1->Panels->Items[2]->Text="t: "
	// +FloatToStrF(float(tk)/1000,ffFixed,6,2);
	// StatusBar1->Panels->Items[3]->Text="ml: "
	// +IntToStr(ml);
	ShowStatus(1, "rv: " + IntToStr(rv));

	ProcessGotResult();
	DrawBoard();

}

void __fastcall TForm1::cmThinkFasterClick(TObject *Sender)
{
	if (GameState == gstSleep)
		return;
	ThinkFaster = true;
	HaveMessage = true;
}
// ---------------------------------------------------------------------------

void TForm1::MakeBoardStr(AnsiString &s)
{
	int i, j;
	char c;
	const TCell *b1;
	s = "";
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 4; j++)
		{
			b1 = &GetLxy(i, (i + 1) % 2 + j * 2);
			c = b1->C;
			if (b1->C != ' ' && b1->Q)
			{
				c = (c == 'b') ? 'B' : 'M';
			}
			s = s + c;
		}
	};
	return;
};

void TForm1::ClearCells()
{
	int i, j;
	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
		{
			CellValue[i][j] = ' ';
		}
	}
};

void TForm1::DrawBoardStr(AnsiString s)
{
	int i, j;
	char c, c1;
	bool q;
	ClearBoard();

	if (s.Length() < 32)
	{
		s = (s + "                                ").SubString(1, 32);
	}

	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 4; j++)
		{
			c = s[i * 4 + j + 1];
			c1 = c;
			q = false;
			if (c == 'B')
			{
				q = true;
				c = 'b';
			};
			if (c == 'M')
			{
				q = true;
				c = 'm';
			};

			if (SetLWB(i, (i + 1) % 2 + j * 2, c, q))
			{
				CellValue[i][(i + 1) % 2 + j * 2] = c1;
			}
		}
	};
	DrawBoard();
	return;
};

void TForm1::SetBoardStr(int n)
{
	if (n < 0 || n >= FBoardStrings->Count)
		return;
	DrawBoardStr(FBoardStrings->Strings[n]);
};

void __fastcall TForm1::cb1DropDown(TObject *Sender)
{
	if (FBoardStrings->Count == 0)
		return;
	if (FBoardStrings->Count == cb1->Items->Count)
		return;
	cb1->Clear();
	int i;
	for (i = 0; i < FBoardStrings->Count; i++)
	{
		cb1->Items->Add(IntToStr(i));
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::cb1Click(TObject *Sender)
{
	int i = cb1->ItemIndex;
	SetBoardStr(i);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cb1KeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
	if (Key != VK_RETURN)
		return;
	cmShowBClick(Sender);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::sbSaveBClick(TObject *Sender)
{
	AnsiString s;
	int n;
	s = cb1->Text;
	if (s.IsEmpty())
		return;
	try
	{
		n = s.ToInt();
	}
	catch (...)
	{
		return;
	};
	if (n < 0 || n >= FBoardStrings->Count)
		return;
	MakeBoardStr(s);
	FBoardStrings->Strings[n] = s;
	FBSChanged = true;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::sbAddBClick(TObject *Sender)
{
	AnsiString s;
	MakeBoardStr(s);
	FBoardStrings->Add(s);
	cb1->Items->Add(IntToStr(FBoardStrings->Count - 1));
	cb1->ItemIndex = cb1->Items->Count - 1;
	FBSChanged = true;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::sbInsertBClick(TObject *Sender)
{
	AnsiString s;
	int n;
	s = cb1->Text;
	try
	{
		n = s.ToInt();
	}
	catch (...)
	{
		return;
	};
	if (n < 0 || n >= FBoardStrings->Count)
		return;
	MakeBoardStr(s);
	FBoardStrings->Insert(n, s);
	FBSChanged = true;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::sbdeleteBClick(TObject *Sender)
{
	AnsiString s;
	int n;
	s = cb1->Text;
	try
	{
		n = s.ToInt();
	}
	catch (...)
	{
		return;
	};
	if (n < 0 || n >= FBoardStrings->Count)
		return;
	FBoardStrings->Delete(n);
	FBSChanged = true;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmShowBClick(TObject *Sender)
{
	AnsiString s;
	int n;
	s = cb1->Text;
	try
	{
		n = s.ToInt();
	}
	catch (...)
	{
		return;
	};
	SetBoardStr(n);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmFullBClick(TObject *Sender)
{
	if (GameState != gstNone && GameState != gstEdit)
		return;
	DefPieces12();
	DrawBoard();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmStartGameClick(TObject *Sender)
{
	if (GameState != gstNone)
		return;
	SetGameType(false);
	GameState = gstStartGame;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmStartGameBClick(TObject *Sender)
{
	if (GameState != gstNone)
		return;
	SetGameType(true);
	GameState = gstStartGame;
}

void __fastcall TForm1::PageControl1Changing(TObject *Sender, bool &AllowChange)
{
	if (!FGameInWay)
		return;
	AllowChange = false;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::PageControl1Change(TObject *Sender)
{
	if (PageControl1->ActivePage == tabEdit)
	{
		GameState = gstEdit;
		return;
	};
	// if(PageControl1->ActivePage==tabPlay)
	// {
	// GameState=gstPlaying;
	// return;
	// };
	if (PageControl1->ActivePage == tabNetGame)
	{
		GameState = gstWaitForConnection;
		return;
	};
	if (PageControl1->ActivePage == tabStartGame);
	{
		GameState = gstNone;
		return;
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmSaveClick(TObject *Sender)
{
	AnsiString s;
	s = ExtractFilePath(Application->ExeName) + "sb.txt";
	try
	{
		FBoardStrings->SaveToFile(s);
	}
	catch (...)
	{;
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmStopGameClick(TObject *Sender)
{
	if (GameState == gstSleep)
		return;
	GameStateX = gstStopGame;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::SetImWhite(bool value)
{
	if (FImWhite == value)
		return;
	if (!FGameInWay)
	{
		FImWhite = value;
		SwapSides();
		DrawBoard();
	};
	if (FImWhite)
		sbImWhite->Down = true;
	else
		sbImBlack->Down = true;
};

void __fastcall TForm1::sbImWhiteClick(TObject *Sender)
{
	ImWhite = sbImWhite->Down;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmTurnBoardClick(TObject *Sender)
{
	if (GameState == gstSleep)
		return;
	TurnBoard = cmTurnBoard->Down;
}
// ---------------------------------------------------------------------------

bool settingmax = false;
void __fastcall TForm1::upd1ChangingEx(TObject *Sender, bool &AllowChange, int NewValue,
		  TUpDownDirection Direction)
{
	cb1DropDown(cb1);
	if (cb1->Items->Count == 0 || NewValue >= cb1->Items->Count)
	{
		AllowChange = false;
		return;
	}
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::upd1Click(TObject *Sender, TUDBtnType Button)
{
	cb1DropDown(cb1);
	if (cb1->Items->Count == 0) return;
	int n = cb1->ItemIndex;
	if(Button == btNext) n++;
	if(Button == btPrev) n--;
	if(n < 0 || n >= cb1->Items->Count ||
		cb1->ItemIndex == n || n >= FBoardStrings->Count) return;
	cb1->ItemIndex = n;
	SetBoardStr(n);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmSaveCBClick(TObject *Sender)
{
	if (GameState == gstSleep)
		return;
	sbAddBClick(sbAddB);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::FOnGTdone(TObject *Sender)
{
	fGameStateX = gstThinkingDone;
	PostMessage(Handle, MyMSG, 0, 0);
};

void TForm1::StartGameThread()
{
	Application->ProcessMessages();
	fGameThread = new TGameThread;
	fGameThread->OnTerminate = FOnGTdone;
	fGameThread->Resume();
};

void __fastcall TGameThread::Execute(void)
{
	FindItX();
};

void __fastcall TForm1::SetConnectTo(String s)
{
	fConnectTo = s;
};

void TForm1::Connect()
{
	if (fConnectTo == "")
		return;
	if (fConnected)
		return;
	fConnected = false;
	scServer->Close();
	scClient->Close();
	scClient->Host = ConnectTo;
	scClient->Port = 303;
	GameState = gstConnecting;
	try
	{
		scClient->Open();
	}
	catch (...)
	{
		scClient->Port = 304;
		try
		{
			scClient->Open();
		}
		catch (...)
		{
			GameState = gstCantConnect;
			return;
		};
	};

};

void __fastcall TForm1::scClientConnect(TObject *Sender,
	TCustomWinSocket *Socket)
{
	fConnected = true;
	GameState = gstConnectedC;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scClientDisconnect(TObject *Sender,
	TCustomWinSocket *Socket)
{
	fConnected = false;
	GameStateX = gstDisConnected;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scClientError(TObject *Sender, TCustomWinSocket *Socket,
	TErrorEvent ErrorEvent, int &ErrorCode)
{
	ErrorCode = 0;
	if (GameState == gstConnecting)
	{
		if (scClient->Port == 304)
		{
			fConnected = false;
			ErrorCode = 0;
			GameState = gstCantConnect;
			return;
		};

		scClient->Port = 304;
		try
		{
			scClient->Open();
			return;
		}
		catch (...)
		{
			fConnected = false;
			ErrorCode = 0;
			GameStateX = gstCantConnect;
			return;
		};
	};

	ErrorCode = 0;
	fConnected = false;
	GameStateX = gstDisConnected;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scServerClientConnect(TObject *Sender,
	TCustomWinSocket *Socket)
{
	if (GameState == gstWaitForConnection)
	{
		fConnected = true;
		GotSocket = Socket;
		GameState = gstConnectedS;
		return;
	};
	fGameStateX = gstCheckServer;
	PostMessage(Handle, MyMSG, 0, 0);
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scServerClientDisconnect(TObject *Sender,
	TCustomWinSocket *Socket)
{
	if (GotSocket == Socket)
	{
		fConnected = false;
		GotSocket = NULL;
		fGameStateX = gstDisConnected;
		PostMessage(Handle, MyMSG, 0, 0);
		return;
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scServerClientError(TObject *Sender,
	TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
	ErrorCode = 0;
	if (GotSocket != Socket)
		return;
	fConnected = false;
	scServer->Close();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmConnectClick(TObject *Sender)
{
	Form1->ConnectTo = cbHostList->Text;
	Form1->Connect();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scServerClientRead(TObject *Sender,
	TCustomWinSocket *Socket)
{
	fGotAnswer = Socket->ReceiveText();
	GameStateX = gstGotSignal;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::scClientRead(TObject *Sender, TCustomWinSocket *Socket)
{
	fGotAnswer = Socket->ReceiveText();
	GameStateX = gstGotSignal;
}
// ---------------------------------------------------------------------------

void TForm1::SendStr(AnsiString s)
{
	if (scServer->Socket->ActiveConnections > 0)
	{
		scServer->Socket->Connections[0]->SendText(s);
		return;
	};
	if (scClient->Socket->Connected)
	{
		scClient->Socket->SendText(s);
	};
};

void __fastcall TForm1::WndProc(Messages::TMessage &Message)
{
	if (Message.Msg == MyMSG)
		DoMuMSG();
	else
		TForm::WndProc(Message);
};

void TForm1::DoMuMSG()
{
	if (fGameStateX != gst0)
	{
		GameStateX = fGameStateX;
		fGameStateX = gst0;
	};
};

void __fastcall TForm1::cmItsMeClick(TObject *Sender)
{
	Application->CreateForm(__classid(TForm3), &Form3);
	Form3->ShowModal();
	delete Form3;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmTurnBoard2Click(TObject *Sender)
{
	TurnBoard = cmTurnBoard2->Down;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmSwapSidesClick(TObject *Sender)
{
	ClearCells();
	SwapSides();
	DrawBoard();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
	int tk, mv, mvx, ml, rv, rv1, gm, sml, ogct;
	AnsiString s;
	if (Key == 'Q' && (Shift.Contains(ssCtrl)))
	{
		GetGameParams(tk, mv, mvx, ml, rv, rv1, ogct, sml, gm);
		s = "rv: " + IntToStr(rv) + "\nrv1 :" + IntToStr(rv1) + "\nn :" +
			IntToStr(mv) + "\nnX:" + IntToStr(mvx) + "\ngm:" + IntToStr(gm) +
			"\nt:" + FloatToStrF(float(tk) / 1000, ffFixed, 6, 2) + "\nout:" +
			IntToStr(ogct) + "\nsml:" + IntToStr(sml) + "\nml:" + IntToStr(ml);
		ShowMessage(s);
	};
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cbTimeLimitClick(TObject *Sender)
{
	int n;
	AnsiString s;
	s = cbTimeLimit->Text;
	if (s == "")
		s = "1";
	try
	{
		n = s.ToInt();
	}
	catch (...)
	{
		return;
	};
	if ((n > 0) && (n < 30))
	{
		TimeMin = n * 1000;
	};
	ActiveControl = NULL;

}

void GetMyServersX(TStrings* sl, PNetResource nr)
{
	PNetResource r, r1;
	HANDLE em;
	int i, j;
	DWORD entn, w, er, bufsz;
	char* pc, pn;
	AnsiString s;
	entn = 0xffffffff;
	bufsz = 16384;
	s = "";
	w = WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY, 0, nr, &em);

	if (w != NO_ERROR)
	{
		return;
	};

	r = PNetResource(GlobalAlloc(GPTR, bufsz));

	do
	{
		w = WNetEnumResource(em, &entn, r, &bufsz);
		if (w != NO_ERROR)
			break;

		for (i = 0; i < entn; i++)
		{
			r1 = &r[i];
			// sl->Add(r1->lpComment);

			if (r1->dwDisplayType == RESOURCEDISPLAYTYPE_SERVER)
			{
				s = r1->lpRemoteName;
				if (s.Length() > 0)
					s.Delete(1, 2);
				sl->Add(s);
				continue;
			};

			if (RESOURCEUSAGE_CONTAINER ==
				(r1->dwUsage & RESOURCEUSAGE_CONTAINER))
			{
				GetMyServersX(sl, r1);
			};
		};
	}
	while (w != NO_ERROR);

	WNetCloseEnum(em);
	GlobalFree((HGLOBAL) r);

}

void TForm1::GetMyServers(TStrings* sl)
{
	sl->Clear();
	GetMyServersX(sl, 0);
}

void __fastcall TForm1::StartTicker(int x, int y)
{
	if (Timer1->Enabled)
		return;
	fTickerCount = 0;
	fTicerGSt = fGameState;
	fGameState = gstSleep;
	fTickerCount = 0;
	Form1->DrawBoard();
	Application->ProcessMessages();
	Form1->GetCellRectX(x - 1, y - 1, fTickerRect);
	Timer1->Enabled = true;

};

void __fastcall TForm1::DoTicker()
{
	if (!Timer1->Enabled)
		return;
	Form1->imBoard->Canvas->Pen->Mode = pmNot;
	Form1->imBoard->Canvas->Rectangle(fTickerRect.Left, fTickerRect.Top,
		fTickerRect.Right, fTickerRect.Bottom);
	Application->ProcessMessages();
	fTickerCount++;
};

void __fastcall TForm1::EndTicker()
{
	Form1->imBoard->Canvas->Pen->Mode = pmCopy;
	fGameState = fTicerGSt;
	Timer1->Enabled = false;
	fTickerCount = 0;
};

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
	if (fTickerCount > 9)
		EndTicker();
	else
		DoTicker();
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
	FDebug = false;
}
// ---------------------------------------------------------------------------

void __fastcall TForm1::cmGetServersClick(TObject *Sender)
{
	if (!fServersListed)
	{
		Application->ProcessMessages();
		GetMyServers(cbHostList->Items);
		fServersListed = true;
	};

}
// ---------------------------------------------------------------------------

void __fastcall TForm1::sbHistBackClick(TObject *Sender)
{
	if (GameState != gstMove || fOnLineGame) return;
	if (FMovesHistory->Count == 0) return;
	if (CurrentHistoryListPos == 0) return;
	CurrentHistoryListPos--;
	AnsiString sb = FMovesHistory->Strings[CurrentHistoryListPos];
	DrawBoardStr(sb);
	BlockMouseClick = (CurrentHistoryListPos % 2) == 1;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::sbHistForwClick(TObject *Sender)
{
	if (GameState != gstMove || fOnLineGame) return;
	if (FMovesHistory->Count == 0) return;
	if (CurrentHistoryListPos >= FMovesHistory->Count - 1) return;
	CurrentHistoryListPos++;
	AnsiString sb = FMovesHistory->Strings[CurrentHistoryListPos];
	DrawBoardStr(sb);
	BlockMouseClick = (CurrentHistoryListPos % 2) == 1;
}
//---------------------------------------------------------------------------

