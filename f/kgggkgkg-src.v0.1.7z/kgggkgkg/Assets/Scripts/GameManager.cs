﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {

	void Start () {
	
	}
	
	void Update () {
	    if (Input.anyKeyDown)
	    {
	        Application.LoadLevel("s1");
	    }
	
	}
}
