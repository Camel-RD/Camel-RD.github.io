﻿using System;
using System.Collections.Generic;
//using UnityEditor;
using UnityEngine;
using System.Collections;

public class PlayManager : MonoBehaviour
{

    public Transform brickPrefab;
    public Transform player;
    public Transform monsterPrefab;
    public Transform lifePrefab;
    public float blockSize = 0.0f;
    public int bricksOnFieldPerCent = 1;

    public float AA_TimeInterval = 3.0f;
    public int moveFPS = 10;
    public int monsterMoveFPS = 10;
    public int monsterMoveBack = 3;
    public int monsterMoveByAA = 3;
    public int monsterMoveByDist = 8;

    private Vector3 _zero = new Vector3();
    private int cellsX, cellsY;
    private Rect cameraRect;

    private Cell[,] Field;
    private Monster[] monsters;
    private int playerX;
    private int playerY;
    private int monstersCount;

    private float lastTime;
    private float lastAATime = 0.0f;
    private float waitTime;
    private int dX, dY;

    private System.Random rnd = new System.Random();

    private GameObject[] lifes = new GameObject[6];
    private GameObject[] monstersCache = new GameObject[10];
    private List<Brick> bricksCache = new List<Brick>();
    private int bricksCacheUsed = 0;

    private int playerLifes = 5;

    private bool gamePaused = false;
    private PlayState playState = PlayState.none;

    private float brickAnimStart = 0.0f;


    public enum CellType
    {
        empty,
        brick,
        player,
        monster
    }

    public enum PlayState
    {
        none,
        firstInit,
        play,
        nextInit,
        brickAnim
    }

    public class Cell
    {
        public CellType cellType = CellType.empty;
        public Brick brick = null;
        public Monster monster = null;

        public void Reset()
        {
            cellType = CellType.empty;
            brick = null;
            monster = null;
        }
    }

    public class Monster
    {
        public int x = 0, y = 0;
        public int xprev = 0, yprev = 0;
        public Vector3 targetpos = new Vector3();
        public float lastTime = 0;
        public bool sleepy = false;
        public GameObject go = null;
    }

    public class Brick
    {
        public int x = 0, y = 0;
        public Vector3 oldpos = new Vector3();
        public Vector3 targetpos = new Vector3();
        public GameObject go = null;
    }

    static int[,] ddxy = new int[8, 2] { { -1, -1 }, { -1, 0 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 1, 0 }, { 1, -1 }, { 0, -1 } };
    
    public class AAStack
    {
        public int[] x;
        public int[] y;
        public int count = 0;

        public void SetSize(int sz)
        {
            x = new int[sz];
            y = new int[sz];
        }
    }

    private AAStack aaStack1 = new AAStack();
    private AAStack aaStack2 = new AAStack();
    private int[,] aaValues1;
    private int[,] aaValues2;


    Vector3 GetCellPos(int x, int y)
    {
        Vector3 pos = new Vector3(x * blockSize + blockSize / 2.0f, y * blockSize + blockSize / 2.0f, 0.0f);
        return pos + _zero;
    }

	void Start ()
	{
        Vector3 ws;
        gamePaused = true;
        ws = Camera.main.ViewportToWorldPoint(new Vector3(1.0f, 1.0f));
        if (brickPrefab == null)
        {
            Debug.LogError("brick == null");
            return;
        }
        if (player == null)
        {
            Debug.LogError("player == null");
            return;
        }
        if (monsterPrefab == null)
        {
            Debug.LogError("monster == null");
            return;
        }
        if (blockSize == 0.0f)
	    {
            Debug.LogError("blockSize == 0");
	        return;
	    }
	    if (bricksOnFieldPerCent < 0 || bricksOnFieldPerCent > 90)
	    {
            Debug.LogError("bad bricksOnFieldPerCent");
            return;
        }

        cellsX = Mathf.FloorToInt(ws.x * 2.0f/ blockSize);
        cellsY = Mathf.FloorToInt(ws.y * 2.0f/ blockSize);
        _zero.x = -cellsX * blockSize / 2.0f;
        _zero.y = -cellsY * blockSize / 2.0f;
        _zero.z = 0.0f;
        
        lastTime = Time.time;
        waitTime = 1.0f / (float)moveFPS;
        dX = 0;
        dY = 0;
        lastAATime = lastTime;
        
        playerLifes = 5;

        InitField();
        SetBorders();
	    MakeLifes();
	    MakeMonstersCache();

        aaStack1.SetSize(cellsX * cellsY);
        aaStack2.SetSize(cellsX * cellsY);
        aaValues1 = new int[cellsX, cellsY];
        aaValues2 = new int[cellsX, cellsY];

        playState = PlayState.firstInit;
	    InitGame(1);
	}

    public void InitGame(int monsterct)
    {
        monstersCount = monsterct;

        ClearField();
        MakePlayer();
        MakeMonsters(monsterct);
        SetRandomBricks();
        MakeField();

        AAClearValues();
        playerLifes = 5;
        CheckLifes();

        if (playState == PlayState.firstInit)
        {
            MoveBricksToPos();
            playState = PlayState.play;
            gamePaused = false;
        }
        else
        {
            brickAnimStart = Time.time;
            playState = PlayState.brickAnim;
        }
    }

    void DoAfterBrickAnim()
    {
        playState = PlayState.play;
        gamePaused = false;
    }

    private void InitField()
    {
        int i, j;
        Field = new Cell[cellsX, cellsY];
        for (i = 0; i < cellsX; i++)
        {
            for (j = 0; j < cellsY; j++)
            {
                Field[i,j] = new Cell();
            }
        }
    }

    private void ClearField()
    {
        int i, j;
        for (i = 1; i < cellsX-1; i++)
        {
            for (j = 1; j < cellsY-1; j++)
            {
                Field[i, j].Reset();
            }
        }
    }

    void SetBorders()
    {
        int i;
        for (i = 0; i < cellsX; i++)
        {
            Field[i, 0].cellType = CellType.brick;
            Field[i, cellsY - 1].cellType = CellType.brick;
        }
        for (i = 0; i < cellsY; i++)
        {
            Field[0, i].cellType = CellType.brick;
            Field[cellsX - 1, i].cellType = CellType.brick;
        }
    }

    void SetRandomBricks()
    {
        int k, x, y;
        int bricksOnField = (cellsX - 2)*(cellsY - 2)*bricksOnFieldPerCent/100;
        k = 0;

        while(k < bricksOnField)
        {
            while (true)
            {
                x = rnd.Next(1, cellsX - 1);
                y = rnd.Next(1, cellsY - 1);
                if (Field[x, y].cellType == CellType.empty)
                {
                    Field[x, y].cellType = CellType.brick;
                    k++;
                    break;
                }
            }
        }
    }

    void MakeMonstersCache()
    {
        Vector3 pos = new Vector3(0.0f,0.0f);
        GameObject go;
        for (int i = 0; i < monstersCache.Length; i++)
        {
            go = ((Transform)GameObject.Instantiate(monsterPrefab, pos, Quaternion.identity)).gameObject;
            go.active = false;
            monstersCache[i] = go;
        }
    }

    void MakeMonsters(int ct)
    {
        int i,y,dy = (cellsY-3)/(ct + 1);
        int px = 5;
        Vector3 pos;
        GameObject go;
        Monster mr;
        monsters = new Monster[ct];
        y = dy;
        for (i = 0; i < ct; i++)
        {
            mr = new Monster();
            monsters[i] = mr;
            mr.x = px;
            mr.y = y;
            mr.lastTime = -1.0f;
            pos = GetCellPos(px, y);
            go = monstersCache[i];
            go.transform.position = pos;
            go.active = true;
            mr.go = go;
            Field[px, y].cellType = CellType.monster;
            Field[px, y].monster = mr;
            y += dy;
        }
        for (i = ct; i < monstersCache.Length; i++)
        {
            monstersCache[i].active = false;
        }
    }

    private void MakePlayer()
    {
        playerX = cellsX - 5;
        playerY = (cellsY - 3) / 2;
        Vector3 pos;
        pos = GetCellPos(playerX, playerY);
        Field[playerX, playerY].cellType = CellType.player;
        player.position = pos;
    }

    void BrickMoveAnim(float t)
    {
        int i, k;
        Brick br;
        k = (cellsX + cellsY)*2-4;
        for (i = k; i < bricksCache.Count; i++)
        {
            br = bricksCache[i];
            br.go.transform.position = Vector3.Lerp(br.oldpos, br.targetpos, t);
        }
    }

    void MoveBricksToPos()
    {
        int i, k;
        Brick br;
        for (i = 0; i < bricksCacheUsed; i++)
        {
            br = bricksCache[i];
            br.go.transform.position = br.targetpos;
        }
    }

    void MakeBrick(int x, int y)
    {
        Vector3 pos;
        Brick br;
        GameObject go;
        pos = GetCellPos(x, y);
        if (bricksCache.Count > bricksCacheUsed)
        {
            br = bricksCache[bricksCacheUsed];
            bricksCacheUsed++;
        }
        else
        {
            br = new Brick();
            go = ((Transform) GameObject.Instantiate(brickPrefab)).gameObject;
            br.go = go;
            bricksCache.Add(br);
            bricksCacheUsed++;
        }
        br.oldpos = br.go.transform.position;
        br.targetpos = pos;
        Field[x, y].brick = br;
    }

    void MakeField()
    {
        int i,j;
        bricksCacheUsed = 0;

        for (i = 0; i < cellsX; i++)
        {
            MakeBrick(i, 0);
            MakeBrick(i, cellsY - 1);
        }
        for (i = 1; i < cellsY-1; i++)
        {
            MakeBrick(0, i);
            MakeBrick(cellsX - 1, i);
        }

        for (i = 1; i < cellsX-1; i++)
        {
            for (j = 1; j < cellsY-1; j++)
            {
                if (Field[i, j].cellType == CellType.brick)
                {
                    MakeBrick(i, j);
                }
            }
        }
    }

    void MakeLifes()
    {
        for (int i = 0; i < lifes.Length; i++)
        {
            GameObject go;
            go = ((Transform) GameObject.Instantiate(lifePrefab)).gameObject;
            lifes[i] = go;
            go.transform.position = GetCellPos(i + 2, 0);
        }
    }

    private void MoveCell(int oldx, int oldy, int newx, int newy)
    {
        Cell cfrom = Field[oldx, oldy];
        Cell cto = Field[newx, newy];
        cto.cellType = cfrom.cellType;
        cfrom.cellType = CellType.empty;
    }

    private void MoveBrickCell(int oldx, int oldy, int newx, int newy)
    {
        Cell cfrom = Field[oldx, oldy];
        Cell cto = Field[newx, newy];
        cto.cellType = cfrom.cellType;
        cfrom.cellType = CellType.empty;
        cto.brick = cfrom.brick;
        cfrom.brick = null;
        cto.brick.go.transform.position = GetCellPos(newx, newy);
    }

    private void MoveMonsterCellA(int oldx, int oldy, int newx, int newy)
    {
        Cell cfrom = Field[oldx, oldy];
        Cell cto = Field[newx, newy];
        cto.cellType = cfrom.cellType;
        cfrom.cellType = CellType.empty;
        cto.monster = cfrom.monster;
        cfrom.monster = null;
    }

    bool MoveBricks(int posx, int posy, int dx, int dy)
    {
        int x1, y1;
        x1 = posx;
        y1 = posy;
        while(true)
        {
            x1 += dx;
            y1 += dy;
            if (x1 <= 0 || y1 <= 0 || x1 >= (cellsX - 1) || y1 >= (cellsY - 1))
            {
                return false;
            }
            if (Field[x1, y1].cellType == CellType.monster)
            {
                return false;
            }
            if (Field[x1, y1].cellType == CellType.empty)
            {
                MoveBrickCell(posx, posy, x1, y1);
                return true;
            }
        }
        return false;
    }

    public bool MovePlayer(int dx, int dy)
    {
        int newx, newy;
        newx = playerX + dx;
        newy = playerY + dy;
        if (Field[newx, newy].cellType == CellType.monster)
        {
            DoBite(Field[newx, newy].monster);
            return false;
        }
        if (Field[newx, newy].cellType == CellType.brick)
        {
            if (dx != 0 && dy != 0) return false;
            if (!MoveBricks(newx, newy, dx, dy)) return false;
        }

        MoveCell(playerX, playerY, newx, newy);
        playerX = newx;
        playerY = newy;
        player.position = GetCellPos(newx, newy);
        return true;
    }

    bool DoIWin()
    {
        int i,j,x1,y1,x2,y2;
        for (i = 0; i < monsters.Length; i++)
        {
            x1 = monsters[i].x;
            y1 = monsters[i].y;
            for (j = 0; j < 8; j++)
            {
                x2 = x1 + ddxy[j, 0];
                y2 = y1 + ddxy[j, 1];
                if (Field[x2, y2].cellType != CellType.brick && Field[x2, y2].cellType != CellType.monster)
                {
                    return false;
                }
            }
        }
        return true;
    }


    private void AAClearValues()
    {
        for (int i = 0; i < cellsX; i++)
            for (int j = 0; j < cellsY; j++)
                aaValues2[i,j] = int.MaxValue;
    }

    void AADoOneRound(int aVal)
    {
        int i, j, k = 0;
        int x1, y1, x2, y2;
        Cell c1;
        aaStack2.count = 0;
        for (i = 0; i < aaStack1.count; i++)
        {
            x1 = aaStack1.x[i];
            y1 = aaStack1.y[i];
            for (j = 0; j < 8; j++)
            {
                x2 = x1 + ddxy[j, 0];
                y2 = y1 + ddxy[j, 1];
                c1 = Field[x2, y2];
                if (aaValues2[x2, y2] == int.MaxValue && (c1.cellType == CellType.empty || c1.cellType == CellType.monster))
                {
                    aaStack2.x[k] = x2;
                    aaStack2.y[k] = y2;
                    aaValues2[x2, y2] = aVal;
                    k++;
                }
            }
        }
        aaStack2.count = k;
    }

    void AADoCalc()
    {
        AAClearValues();
        aaValues2[playerX, playerY] = -1;
        aaStack1.count = 1;
        aaStack2.count = 0;
        aaStack1.x[0] = playerX;
        aaStack1.y[0] = playerY;
        int k = 1;
        AAStack aaStack3;
        do
        {
            AADoOneRound(k);
            k++;
            if (aaStack2.count == 0)
            {
                var aav = aaValues1;
                aaValues1 = aaValues2;
                aaValues2 = aav;
                return;
            }
            aaStack3 = aaStack1;
            aaStack1 = aaStack2;
            aaStack2 = aaStack3;
        } while (true);
    }

    public void MoveMonster(Monster mr, out int newx, out int newy)
    {
        int i,x1, y1, x2, y2;
        int freecellcount = 0;
        int freecellcount2 = 0;
        int k,kaa, kdist, konly, aamin, distmin;
        bool goback = false;

        kaa = -1;
        kdist = -1;
        konly = -1;
        aamin = int.MaxValue;
        distmin = Math.Abs(playerX - mr.x) + Math.Abs(playerY - mr.y);

        goback = rnd.Next(0, 10) < monsterMoveBack;
        newx = -1;
        newy = -1;
        x1 = mr.x;
        y1 = mr.y;

        for (i = 0; i < 8; i++)
        {
            x2 = x1 + ddxy[i, 0];
            y2 = y1 + ddxy[i, 1];
            if (Field[x2, y2].cellType == CellType.player)
            {
                newx = x2;
                newy = y2;
                return;
            }
            
            if (Field[x2, y2].cellType != CellType.empty) continue;

            if (konly == -1)
            {
                konly = i;
            }
            else
            {
                konly = -2;
            }

            freecellcount++;
            freecellcount2++;
            if ((!goback) && x2 == mr.xprev && y2 == mr.yprev) freecellcount2--;

            k = aaValues1[x2, y2];
            if (k < aamin)
            {
                aamin = k;
                kaa = i;
            }

            k = Math.Abs(playerX - x2) + Math.Abs(playerY - y2);
            if (k < distmin)
            {
                distmin = k;
                kdist = i;
            }
        }

        if (konly == -1) return;

        if (konly > -1)
        {
            newx = x1 + ddxy[konly, 0];
            newy = y1 + ddxy[konly, 1];
            return;
        }

        k = rnd.Next(0, 10);
        if (k < monsterMoveByAA && kaa > -1)
        {
            newx = x1 + ddxy[kaa, 0];
            newy = y1 + ddxy[kaa, 1];
            return;
        }

        if (k < monsterMoveByDist && kdist > -1)
        {
            x2 = x1 + ddxy[kdist, 0];
            y2 = y1 + ddxy[kdist, 1];
            if ((!goback) && x2 == mr.xprev && y2 == mr.yprev)
            {

            }
            else
            {
                newx = x2;
                newy = y2;
                return;
            }
        }

        if (freecellcount2 == 0) return;

        k = rnd.Next(1, freecellcount2+1);
        
        for (i = 0; i < 8; i++)
        {
            x2 = x1 + ddxy[i, 0];
            y2 = y1 + ddxy[i, 1];
            if (Field[x2, y2].cellType != CellType.empty) continue;
            k--;
            if ((!goback) && x2 == mr.xprev && y2 == mr.yprev) k++;
            if (k == 0)
            {
                newx = x2;
                newy = y2;
                return;
            }
        }
    }

    void DoBite(Monster mr)
    {
        if (mr.sleepy) return;
        mr.lastTime += 5.0f;
        mr.sleepy = true;
        playerLifes--; 
        CheckLifes();
        if (playerLifes == 0)
        {
            ILoose();
        }
    }

    void ILoose()
    {
        gamePaused = true;
        playState = PlayState.nextInit;
        InitGame(1);
    }

    void IWin()
    {
        gamePaused = true;
        playState = PlayState.nextInit;
        if (monstersCount < 9)
        {
            InitGame(monstersCount + 1);
        }
        else
        {
            InitGame(1);
        }
    }

    void UpdateMonsters()
    {
        int i;
        int newx, newy;
        Monster mr;
        Vector3 pos;
        for (i = 0; i < monsters.Length; i++)
        {
            mr = monsters[i];
            if (mr.lastTime == -1.0f)
            {
                mr.lastTime = Time.time + (float)rnd.Next(1, monsterMoveFPS) / (float)monsterMoveFPS;
                mr.targetpos = mr.go.transform.position;
                continue;
            }
            if (Time.time - mr.lastTime > 1.0f/monsterMoveFPS)
            {
                mr.sleepy = false;
                mr.go.transform.position = mr.targetpos;
                MoveMonster(mr, out newx, out newy);
                if (newx > -1)
                {
                    if (newx == playerX && newy == playerY)
                    {
                        DoBite(mr);
                        return;
                    }
                    MoveMonsterCellA(mr.x, mr.y, newx, newy);
                    mr.targetpos = GetCellPos(newx, newy);
                    Field[mr.x, mr.y].monster = null;
                    Field[newx, newy].monster = mr;
                    mr.xprev = mr.x;
                    mr.yprev = mr.y;
                    mr.x = newx;
                    mr.y = newy;
                    mr.lastTime = Time.time;
                }
            }
            else
            {
                pos = mr.go.transform.position;
                pos = Vector3.MoveTowards(pos, mr.targetpos, blockSize / monsterMoveFPS);
                mr.go.transform.position = pos;
            }
        }
    }

    void UpdatePlayer()
    {
        int dx = 0, dy = 0;
        float nowTime = Time.time;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) dy += 1;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) dy -= 1;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) dx -= 1;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) dx += 1;
        if (dx != 0 || dy != 0)
        {
            if ((nowTime - lastTime >= waitTime) || dx != dX || dy != dY)
            {
                if (MovePlayer(dx, dy))
                {
                    dX = dx;
                    dY = dy;
                    lastTime = nowTime;
                    if (DoIWin()) IWin();
                }
                else
                {
                    dX = 0;
                    dY = 0;
                }
            }
        }
    }

    void UpdateAA()
    {
        float nowTime = Time.time;
        if (nowTime - lastAATime > AA_TimeInterval)
        {
            AADoCalc();
            lastAATime = nowTime;
        }
    }

    void CheckLifes()
    {
        for (int i = 0; i < lifes.Length; i++)
        {
            lifes[i].active = i < playerLifes;
        }
    }

	void Update ()
	{
        if (Input.GetKey(KeyCode.Escape))
	    {
	        Application.Quit();
	    }
        
        float f,nowTime = Time.time;
	    if (playState == PlayState.brickAnim)
	    {
	        f = (nowTime - brickAnimStart) / 5.0f;
	        if (f <= 1.0f)
	        {
	            BrickMoveAnim(f);
	        }
	        else
	        {
                BrickMoveAnim(1.0f);
	            DoAfterBrickAnim();
	            return;
	        }
	    }

	    if (playState == PlayState.play && !gamePaused)
	    {
	        UpdatePlayer();
	        UpdateMonsters();
	        UpdateAA();
            return;
        }
	}
}
